
//-- Create ------------------------------------------------------------------------------------------------------------

movieWorld.v.actors.createActor = function () {
    var saveButton = document.getElementById("saveButton");
    Person.listAllPersons();
    Actor.listAllActors();
    var createActorForm = document.forms['createActor'];
    var actorIdLabel = createActorForm.actorsId;
    var actorNameLabel = createActorForm.actorsName;
    var agentLabel = createActorForm.selectAgent;
    util.fillSelectWithOptions(agentLabel, Person.instances, "personsName");

    actorIdLabel.addEventListener("input", function () {
        console.log(actorIdLabel.value)
        var validationResultID = Actor.checkPersonsId(actorIdLabel.value, Actor);
        actorIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, actorIdLabel);
    });

    actorNameLabel.addEventListener("input", function () {
        var validationResultTitle = Actor.checkPersonsName(actorNameLabel.value);
        actorNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, actorNameLabel);
    });

    agentLabel.addEventListener("change", function () {
        var agent = Person.instances[agentLabel.value];
    });

    saveButton.addEventListener("click", function () {
        var numOfMoviesRow = {
            _personsId: createActorForm.actorsId.value,
            _personsName: createActorForm.actorsName.value,
            _agent: Person.instances[agentLabel.value]
        };

        var validationResultID = Actor.checkPersonsId(actorIdLabel.value, Actor);
        actorIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, actorIdLabel);

        var validationResultTitle = Actor.checkPersonsName(actorNameLabel.value);
        actorNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, actorNameLabel);

        if (createActorForm.checkValidity()) {
            Actor.create(numOfMoviesRow);
            Actor.saveActors();
            createActorForm.reset();
        }
    });
};

//-- Update ------------------------------------------------------------------------------------------------------------

movieWorld.v.actors.updateActor = function () {
    document.getElementById("saveButton").style.display = "none";
    Person.listAllPersons();
    Actor.listAllActors();
    var updateButton = document.getElementById("updateButton");
    var actorToBeUpdated = document.getElementById("selectActorToBeUpdated");
    var allActors = Actor.instances;
    var updateActorForm = document.forms['updateActor'];
    var agentLabel = updateActorForm.selectAgent;
    util.fillSelectWithOptions(agentLabel, Person.instances, "personsName");
    var nameLabel = document.getElementById("names_act2");
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allActors) {
        var newOption = document.createElement("option");
        newOption.text = allActors[i]._personsName;
        newOption.value = allActors[i]._personsId;
        actorToBeUpdated.add(newOption)
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }

    actorToBeUpdated.addEventListener("change", function () {
        nameLabel.value = allActors[actorToBeUpdated.value]._personsName;
    });

    nameLabel.addEventListener("input", function () {
        var validationResultTitle = Actor.checkPersonsName(nameLabel.value);
        nameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, nameLabel);
    });

    agentLabel.addEventListener("change", function () {
        var agent = Person.instances[agentLabel.value];
        console.log(agent)
    });

    updateButton.addEventListener("click", function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (actorToBeUpdated.value === arrayOfIDs[i]) {
                var numOfMoviesRow = {
                    _personsId: actorToBeUpdated.value,
                    _personsName: nameLabel.value,
                    _agent: Person.instances[agentLabel.value]
                };
                var validationResultTitle = Actor.checkPersonsName(nameLabel.value);
                nameLabel.setCustomValidity(validationResultTitle.message);
                setColorToInput(validationResultTitle, nameLabel);
                if (updateActorForm.checkValidity()) {
                    Actor.update(numOfMoviesRow);
                    updateActorForm.reset();
                }
            }
        }
    });
};

//-- Delete ------------------------------------------------------------------------------------------------------------

movieWorld.v.actors.deleteActor = function () {
    Actor.listAllActors();
    document.getElementById("saveButton").style.display = "none";
    var deleteButton = document.getElementById("deleteButton");
    var actorToBeDeleted = document.getElementById("selectActorToBeDeleted");
    var allActors = Actor.instances;
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allActors) {
        var newOption = document.createElement("option");
        newOption.text = allActors[i]._personsName;
        newOption.value = allActors[i]._personsId;
        actorToBeDeleted.add(newOption)
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }
    deleteButton.onclick = function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (actorToBeDeleted.value === arrayOfIDs[i]) {
                Actor.delete(arrayOfIDs[i])
            }
        }
        Actor.saveActors();
    }
};

//-- List ------------------------------------------------------------------------------------------------------------

movieWorld.v.actors.listingAllActors = function () {
    document.getElementById("saveButton").style.display = "none";
    Actor.listAllActors();
    Movie.listAllMovies();
    var allActors = Actor.instances;
    var tableOfActors = document.getElementById('TableOfAllActors');
    for (let i in allActors) {
        var counterOfActors = 1;
        var newRow = document.createElement("tr");
        newRow.id = "tr_newRow";
        var colOfIDs = document.createElement("td");
        colOfIDs.id = "td_Ids";
        var colOfNames = document.createElement("td");
        colOfNames.id = "td_titles";
        var colOfPlayedMovies = document.createElement("td");
        colOfPlayedMovies.id = "td_plMovies";
        var colOfAgents = document.createElement("td");
        colOfAgents.id = "td_agents";
        var textOfID = document.createElement("h3");
        var textOfTitles = document.createElement("h3");
        var textOfPlayedMovies = document.createElement("h3");
        var textOfAgents = document.createElement("h3");
        textOfID.textContent = allActors[i]._personsId;
        colOfIDs.appendChild(textOfID);
        textOfTitles.textContent = allActors[i]._personsName;
        colOfNames.appendChild(textOfTitles);
        textOfAgents.textContent = allActors[i]._agent._personsName;
        colOfAgents.appendChild(textOfAgents);
        for (let pM in allActors[i]._playedMovies) {
            console.log(Object.keys(allActors[i]._playedMovies).length)
            textOfPlayedMovies.textContent
                += allActors[i]._playedMovies[pM];
            if (counterOfActors < Object.keys(allActors[i]._playedMovies).length) {
                textOfPlayedMovies.textContent += ", "
            }
            counterOfActors++;
        }
        colOfPlayedMovies.appendChild(textOfPlayedMovies);
        newRow.append(colOfIDs, colOfNames, colOfPlayedMovies, colOfAgents);
        tableOfActors.appendChild(newRow)
    }
};

//-- Back --------------------------------------------------------------------------------------------------------------

function goBackToActorsPage() {
    location.href = "manageActors.html";
}
