
//-- Create ------------------------------------------------------------------------------------------------------------

movieWorld.v.movies.createMovie = function () {
    var saveButton = document.getElementById("saveButton");
    Movie.listAllMovies();
    Director.listAllDirectors();
    Actor.listAllActors();

    var createMovieForm = document.forms['createMovie'];
    var movieIdLabel = createMovieForm.movieId;
    var titleLabel = createMovieForm.title;
    var releaseDateLabel = createMovieForm.releaseDate;
    var ratingSection = document.getElementById("rating");
    var genresSection = document.getElementById("genres");
    var directorSelector = createMovieForm.selectDirector;
    var actorsSelector = createMovieForm.selectActors;
    var typeOfMovieSector = createMovieForm.selectTypeOfMovie;
    var aboutField = document.getElementById("field_About");
    var tvSerieField = document.getElementById("field_TV_Serie");
    var aboutLabel = createMovieForm.about;
    var tvSerieNo = createMovieForm.tvArea_no;
    var tvSerieName = createMovieForm.tvArea_name;

    util.createChoiceWidget(ratingSection, "rating", [],
        "radio",
        MovieRatingEL.labels);
    util.createChoiceWidget(genresSection, "genres", [],
        "checkbox",
        GenreEL.labels, true);
    util.fillSelectWithOptions(directorSelector, Director.instances, "directorsName");
    util.fillSelectWithOptions(actorsSelector, Actor.instances, "actorsName");
    util.fillSelectWithOptions(typeOfMovieSector, MovieCategoryEL.labels);

    movieIdLabel.addEventListener("input", function () {
        var validationResultID = Movie.checkId(movieIdLabel.value);
        movieIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, movieIdLabel);
    });

    titleLabel.addEventListener("input", function () {
        var validationResultTitle = Movie.checkTitle(titleLabel.value);
        titleLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, titleLabel);
    });

    releaseDateLabel.addEventListener("input", function () {
        var validationResultDate = Movie.checkReleaseDate(
            releaseDateLabel.value);
        releaseDateLabel.setCustomValidity(validationResultDate.message);
        setColorToInput(validationResultDate, releaseDateLabel);
    });

    ratingSection.addEventListener("click", function () {
        var validationResultRating = Movie.checkRating(
            ratingSection.getAttribute("data-value"));
        ratingSection.setCustomValidity(validationResultRating.message);
    });

    genresSection.addEventListener("click", function () {
        var validationResultGenre = Movie.checkGenres(JSON.parse(
            genresSection.getAttribute("data-value")));
        genresSection.setCustomValidity(validationResultGenre.message);
        setColorToInput(validationResultGenre, genresSection);
    });

    var arrayOfActors = [];
    actorsSelector.addEventListener("change", function () {
        arrayOfActors = [];
        for (let opt of actorsSelector.selectedOptions) {
            arrayOfActors.push(Actor.instances[opt.value]);
        }
        arrayOfActors = Array.from(new Set(arrayOfActors));
        var validationResult = Movie.checkActors(arrayOfActors);
        actorsSelector.setCustomValidity(validationResult.message);
    });

    var typeOfMovie;
    typeOfMovieSector.addEventListener("change", function () {
        if (parseInt(typeOfMovieSector.value) === 0) {
            typeOfMovie = MovieCategoryEL.BIOGRAPHY;
            tvSerieField.style.display = "none";
            aboutField.style.display = "block";
        } else if (parseInt(typeOfMovieSector.value) === 1) {
            typeOfMovie = MovieCategoryEL.TVSERIESEPISODE;
            aboutField.style.display = "none";
            tvSerieField.style.display = "block";
        } else {
            typeOfMovie = undefined;
            console.log(typeOfMovie)
            aboutField.style.display = "none";
            tvSerieField.style.display = "none";
        }
        var validationResultTypeOfMovie = Movie.checkTypeOfMovie(typeOfMovie);
        typeOfMovieSector.setCustomValidity(validationResultTypeOfMovie.message);
    });

    aboutLabel.addEventListener("input", function () {
        var validationResultAbout = Movie.checkAboutSection(aboutLabel.value);
        console.log(validationResultAbout);
        aboutLabel.setCustomValidity(validationResultAbout.message);
        setColorToInput(validationResultAbout, aboutLabel);
    });

    tvSerieNo.addEventListener("input", function () {
        var validationResultTvSerieNo = Movie.checkNoOfEpisode(tvSerieNo.value);
        console.log(validationResultTvSerieNo)
        tvSerieNo.setCustomValidity(validationResultTvSerieNo.message);
        setColorToInput(validationResultTvSerieNo, tvSerieNo);
    });

    tvSerieName.addEventListener("input", function () {
        var validationResultTvSerieName = Movie.checkNameOfTVSerie(tvSerieName.value);
        console.log(validationResultTvSerieName);
        tvSerieName.setCustomValidity(validationResultTvSerieName.message);
        setColorToInput(validationResultTvSerieName, tvSerieName);
    });

    saveButton.addEventListener("click", function () {
        console.log(typeOfMovie)
        var numOfMoviesRow = {
            _movieId: createMovieForm.movieId.value,
            _title: createMovieForm.title.value,
            _releaseDate: createMovieForm.releaseDate.value,
            _rating: ratingSection.getAttribute("data-value"),
            _genres: JSON.parse(genresSection.getAttribute("data-value")),
            _director: Director.instances[directorSelector.value],
            _actors: arrayOfActors,
            _typeOfMovie: typeOfMovie,
            _about: aboutLabel.value,
            _episodeNo: tvSerieNo.value,
            _nameOfTVSerie: tvSerieName.value
        };

        var validationResultID = Movie.checkId(movieIdLabel.value);
        movieIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, movieIdLabel);
        var validationResultTitle = Movie.checkTitle(titleLabel.value);
        titleLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, titleLabel);
        var validationResultDate = Movie.checkReleaseDate(releaseDateLabel.value);
        releaseDateLabel.setCustomValidity(validationResultDate.message);
        setColorToInput(validationResultDate, releaseDateLabel);
        var validationResultRating = Movie.checkRating(ratingSection.getAttribute("data-value"));
        ratingSection.setCustomValidity(validationResultRating.message);
        var validationResultGenre = Movie.checkGenres(JSON.parse(genresSection.getAttribute("data-value")));
        createMovieForm.genres[1].setCustomValidity(validationResultGenre.message);
        setColorToInput(validationResultGenre, genresSection);
        var validationResult = Movie.checkActors(arrayOfActors);
        actorsSelector.setCustomValidity(validationResult.message);
        setColorToInput(validationResult, actorsSelector)
        var validationResultTypeOfMovie = Movie.checkTypeOfMovie(typeOfMovie);
        typeOfMovieSector.setCustomValidity(validationResultTypeOfMovie.message);
        if (typeOfMovie !== undefined) {
            if (typeOfMovie === MovieCategoryEL.BIOGRAPHY) {
                var validationResultAbout = Movie.checkAboutSection(aboutLabel.value);
                console.log(validationResultAbout);
                aboutLabel.setCustomValidity(validationResultAbout.message);
                setColorToInput(validationResultAbout, aboutLabel);
            } else {
                var validationResultTvSerieNo = Movie.checkNoOfEpisode(tvSerieNo.value);
                console.log(validationResultTvSerieNo)
                tvSerieNo.setCustomValidity(validationResultTvSerieNo.message);
                setColorToInput(validationResultTvSerieNo, tvSerieNo);
                var validationResultTvSerieName = Movie.checkNameOfTVSerie(tvSerieName.value);
                console.log(validationResultTvSerieName);
                tvSerieName.setCustomValidity(validationResultTvSerieName.message);
                setColorToInput(validationResultTvSerieName, tvSerieName);
            }
        }
        if (createMovieForm.checkValidity()) {
            Movie.create(numOfMoviesRow);
            Movie.saveAllMovies();
            createMovieForm.reset();
        }
    });
};

//-- Update ------------------------------------------------------------------------------------------------------------

movieWorld.v.movies.updateMovie = function () {

    document.getElementById("saveButton").style.display = "none";
    Movie.listAllMovies();
    Director.listAllDirectors();
    Actor.listAllActors();

    var updateButton = document.getElementById("updateButton");
    var movieToBeUpdated = document.getElementById("selectMovieToBeUpdated");
    var allMovies = Movie.instances;
    var updateMovieForm = document.forms['updateMovie'];
    var titleLabel = document.getElementById("title2");
    var releaseDateLabel = document.getElementById("releaseDate2");
    var ratingSection = document.getElementById("rating2");
    var genresSection = document.getElementById("genres2");
    var directorSelector = updateMovieForm.selectDirector;
    var actorsSelector = updateMovieForm.selectActors;
    var typeOfMovieSector = updateMovieForm.selectTypeOfMovie;
    var tvSerieField = document.getElementById("field_TV_Serie2");
    var aboutField = document.getElementById("field_About2");
    var aboutLabel = updateMovieForm.about;
    var tvSerieNo = updateMovieForm.tvArea_no;
    var tvSerieName = updateMovieForm.tvArea_name;
    var typeOfMovie;
    var arrayOfTitles = [];
    var arrayOfIDs = [];
    for (let i in allMovies) {
        var newOption = document.createElement("option");
        newOption.text = allMovies[i].title;
        newOption.value = allMovies[i].movieId;
        movieToBeUpdated.add(newOption);
        arrayOfTitles[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }

    movieToBeUpdated.addEventListener("change", function () {
        titleLabel.value = allMovies[movieToBeUpdated.value].title;
        releaseDateLabel.value = allMovies[movieToBeUpdated.value].releaseDate;

        util.createChoiceWidget(ratingSection, "rating2",
            [allMovies[movieToBeUpdated.value].rating],
            "radio", MovieRatingEL.labels);
        util.createChoiceWidget(genresSection, "genres2",
            allMovies[movieToBeUpdated.value].genres, "checkbox", GenreEL.labels);
        util.fillSelectWithOptions(directorSelector, Director.instances, "directorsName");
        util.fillSelectWithOptions(actorsSelector, Actor.instances, "actorsName");

        if (allMovies[movieToBeUpdated.value]._typeOfMovie === "") {
            (document.getElementById("typeM")).textContent = "Type: ";
            typeOfMovieSector = document.createElement("select");
            (document.getElementById("typeM")).appendChild(typeOfMovieSector);
            util.fillSelectWithOptions(typeOfMovieSector, MovieCategoryEL.labels);
            typeOfMovieSector.addEventListener("change", function () {
                if (parseInt(typeOfMovieSector.value) === 0) {
                    typeOfMovie = MovieCategoryEL.BIOGRAPHY;
                    tvSerieField.style.display = "none";
                    aboutField.style.display = "block";
                } else if (parseInt(typeOfMovieSector.value) === 1) {
                    typeOfMovie = MovieCategoryEL.TVSERIESEPISODE;
                    aboutField.style.display = "none";
                    tvSerieField.style.display = "block";
                } else {
                    typeOfMovie = undefined;
                    aboutField.style.display = "none";
                    tvSerieField.style.display = "none";
                }
                var validationResultTypeOfMovie = Movie.checkTypeOfMovie(typeOfMovie);
                typeOfMovieSector.setCustomValidity(validationResultTypeOfMovie.message);
            });
        } else { //if already chosen then display category
            typeOfMovieSector.style.display = "none";
            (document.getElementById("typeM")).textContent = "Type: "
                + MovieCategoryEL.labels[allMovies[movieToBeUpdated.value]._typeOfMovie - 1];
        }
    });

    titleLabel.addEventListener("input", function () {
        var validationResultTitle = Movie.checkTitle(titleLabel.value);
        titleLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, titleLabel);
    });

    releaseDateLabel.addEventListener("input", function () {
        var validationResultDate = Movie.checkReleaseDate(releaseDateLabel.value);
        releaseDateLabel.setCustomValidity(validationResultDate.message);
        setColorToInput(validationResultDate, releaseDateLabel);
    });

    ratingSection.addEventListener("click", function () {
        var validationResultRating = Movie.checkRating(
            ratingSection.getAttribute("data-value"));
        ratingSection.setCustomValidity(validationResultRating.message);
    });

    genresSection.addEventListener("click", function () {
        var validationResultGenre = Movie.checkGenres(JSON.parse(genresSection.getAttribute("data-value")));
        genresSection.setCustomValidity(validationResultGenre.message);
        setColorToInput(validationResultGenre, genresSection);
    });

    var arrayOfActors = [];
    actorsSelector.addEventListener("change", function () {
        arrayOfActors = [];
        for (let opt of actorsSelector.selectedOptions) {
            arrayOfActors.push(Actor.instances[opt.value]);
        }
        arrayOfActors = Array.from(new Set(arrayOfActors));
    });

    aboutLabel.addEventListener("input", function () {
        var validationResultAbout = Movie.checkAboutSection(aboutLabel.value);
        console.log(validationResultAbout);
        aboutLabel.setCustomValidity(validationResultAbout.message);
        setColorToInput(validationResultAbout, aboutLabel);
    });

    tvSerieNo.addEventListener("input", function () {
        var validationResultTvSerieNo = Movie.checkNoOfEpisode(tvSerieNo.value);
        console.log(validationResultTvSerieNo);
        tvSerieNo.setCustomValidity(validationResultTvSerieNo.message);
        setColorToInput(validationResultTvSerieNo, tvSerieNo);
    });

    tvSerieName.addEventListener("input", function () {
        var validationResultTvSerieName = Movie.checkNameOfTVSerie(tvSerieName.value);
        console.log(validationResultTvSerieName);
        tvSerieName.setCustomValidity(validationResultTvSerieName.message);
        setColorToInput(validationResultTvSerieName, tvSerieName);
    });


    updateButton.addEventListener("click", function () {
        for (let i = 1; i < arrayOfTitles.length; i++) {
            if (movieToBeUpdated.value === arrayOfIDs[i]) {
                if (arrayOfActors.length === 0) {
                    arrayOfActors = Movie.instances[movieToBeUpdated.value]._actors;
                }
                var numOfMoviesRow = {
                    _movieId: movieToBeUpdated.value,
                    _title: titleLabel.value,
                    _releaseDate: releaseDateLabel.value,
                    _rating: ratingSection.getAttribute("data-value"),
                    _genres: JSON.parse(genresSection.getAttribute("data-value")),
                    _director: Director.instances[directorSelector.value],
                    _actors: arrayOfActors,
                    _typeOfMovie: typeOfMovie,
                    _about: aboutLabel.value,
                    _episodeNo: tvSerieNo.value,
                    _nameOfTVSerie: tvSerieName.value
                };
                var validationResultTitle = Movie.checkTitle(titleLabel.value);
                titleLabel.setCustomValidity(validationResultTitle.message);
                setColorToInput(validationResultTitle, titleLabel);
                var validationResultDate = Movie.checkReleaseDate(releaseDateLabel.value);
                releaseDateLabel.setCustomValidity(validationResultDate.message);
                setColorToInput(validationResultDate, releaseDateLabel);
                var validationResultRating = Movie.checkRating(ratingSection.getAttribute("data-value"));
                ratingSection.setCustomValidity(validationResultRating.message);
                var validationResultGenre = Movie.checkGenres(JSON.parse(genresSection.getAttribute("data-value")));
                genresSection.setCustomValidity(validationResultGenre.message);
                setColorToInput(validationResultGenre, genresSection);

                if (typeOfMovie !== undefined) {
                    if (typeOfMovie === MovieCategoryEL.BIOGRAPHY) {
                        var validationResultAbout = Movie.checkAboutSection(aboutLabel.value);
                        console.log(validationResultAbout);
                        aboutLabel.setCustomValidity(validationResultAbout.message);
                        setColorToInput(validationResultAbout, aboutLabel);
                    } else {
                        var validationResultTvSerieNo = Movie.checkNoOfEpisode(tvSerieNo.value);
                        console.log(validationResultTvSerieNo);
                        tvSerieNo.setCustomValidity(validationResultTvSerieNo.message);
                        setColorToInput(validationResultTvSerieNo, tvSerieNo);

                        var validationResultTvSerieName = Movie.checkNameOfTVSerie(tvSerieName.value);
                        console.log(validationResultTvSerieName);
                        tvSerieName.setCustomValidity(validationResultTvSerieName.message);
                        setColorToInput(validationResultTvSerieName, tvSerieName);
                    }
                }

                if (updateMovieForm.checkValidity()) {
                    Movie.update(numOfMoviesRow);
                    Movie.saveAllMovies();
                    updateMovieForm.reset();
                }
            }
        }
    });
};

//-- Delete ------------------------------------------------------------------------------------------------------------

movieWorld.v.movies.deleteMovie = function () {
    Movie.listAllMovies();
    document.getElementById("saveButton").style.display = "none";
    var deleteButton = document.getElementById("deleteButton");
    var movieToBeDeleted = document.getElementById("selectMovieToBeDeleted");
    var allMovies = Movie.instances;
    var arrayOfTitles = [];
    var arrayOfIDs = [];
    for (let i in allMovies) {
        var newOption = document.createElement("option");
        newOption.text = allMovies[i].title;
        newOption.value = allMovies[i].movieId;
        movieToBeDeleted.add(newOption)
        arrayOfTitles[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }
    deleteButton.onclick = function () {
        for (let i = 1; i < arrayOfTitles.length; i++) {
            if (movieToBeDeleted.value === arrayOfIDs[i]) {
                Movie.delete(arrayOfIDs[i])
            }
        }
        Movie.saveAllMovies();
    }
};

//-- List ------------------------------------------------------------------------------------------------------------

movieWorld.v.movies.listingAllMovies = function () {
    document.getElementById("saveButton").style.display = "none";
    Movie.listAllMovies();
    console.log(Movie.instances)
    var allMovies = Movie.instances;
    var tableOfMovies = document.getElementById('TableOfAllMovie');
    console.log(tableOfMovies)
    for (let i in allMovies) {
        var newRow = document.createElement("tr");
        newRow.id = "tr_newRow";
        var colOfIDs = document.createElement("td");
        colOfIDs.id = "td_Ids";
        var colOfTitles = document.createElement("td");
        colOfTitles.id = "td_titles";
        var colOfDates = document.createElement("td");
        colOfDates.id = "td_dates";
        var colOfRatings = document.createElement("td");
        colOfRatings.id = "td_Ratings";
        var colOfGenres = document.createElement("td");
        colOfGenres.id = "td_Genres";
        var colOfDirectors = document.createElement("td");
        colOfDirectors.id = "td_dirs";
        var colOfActors = document.createElement("td");
        colOfActors.id = "td_acts";
        var colOfType = document.createElement("td");
        colOfType.id = "td_type";
        var textOfID = document.createElement("h3");
        var textOfTitles = document.createElement("h3");
        var textOfDates = document.createElement("h3");
        var textOfRatings = document.createElement("h3");
        var textOfGenres = document.createElement("h3");
        var textOfDirectors = document.createElement("h3");
        var textOfActors = document.createElement("h3");
        var textOfType = document.createElement("h3");
        textOfID.textContent = allMovies[i].movieId;
        colOfIDs.appendChild(textOfID);
        textOfTitles.textContent = allMovies[i].title;
        colOfTitles.appendChild(textOfTitles);
        textOfDates.textContent = allMovies[i].releaseDate;
        colOfDates.appendChild(textOfDates);
        textOfRatings.textContent = MovieRatingEL.labels[allMovies[i].rating - 1];
        colOfRatings.appendChild(textOfRatings);
        textOfGenres.textContent = GenreEL.convertEnumIndexes2Names(allMovies[i].genres);
        colOfGenres.appendChild(textOfGenres);
        textOfType.textContent = MovieCategoryEL.labels[allMovies[i]._typeOfMovie - 1];
        if (allMovies[i]._typeOfMovie === MovieCategoryEL.BIOGRAPHY) {
            textOfType.textContent += ": " + allMovies[i]._about;
        } else if (allMovies[i]._typeOfMovie === MovieCategoryEL.TVSERIESEPISODE) {
            textOfType.textContent += ": EpisodeNo: " + allMovies[i]._episodeNo +
                " Episode name: " + allMovies[i]._nameOfTVSerie;
        }
        colOfType.appendChild(textOfType);
        textOfDirectors.textContent = allMovies[i]._director._personsName;
        colOfDirectors.appendChild(textOfDirectors);
        for (let acts of allMovies[i]._actors) {
            textOfActors.textContent += acts._personsName;
            if (allMovies[i]._actors[allMovies[i]._actors.length - 1] !== acts) {
                textOfActors.textContent += ", ";
            }
        }
        colOfActors.appendChild(textOfActors);
        console.log(tableOfMovies);
        newRow.append(colOfIDs, colOfTitles, colOfDates, colOfRatings,
            colOfGenres, colOfDirectors, colOfActors, colOfType);
        tableOfMovies.appendChild(newRow)
    }
};

//-- Back ------------------------------------------------------------------------------------------------------------

function goBackToMoviesPage() {
    location.href = "manageMovies.html";
}

