
//-- Create ------------------------------------------------------------------------------------------------------------

movieWorld.v.people.createPerson = function () {
    var saveButton = document.getElementById("saveButton");
    Person.listAllPersons();
    console.log(Person.instances)
    var createPersonForm = document.forms['createPerson'];
    var personIdLabel = createPersonForm.personsId;
    var personNameLabel = createPersonForm.personsName;

    personIdLabel.addEventListener("input", function () {
        var validationResultID = Person.checkPersonsId(personIdLabel.value, Person);
        personIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, personIdLabel);
    });

    personNameLabel.addEventListener("input", function () {
        var validationResultTitle = Person.checkPersonsName(personNameLabel.value);
        personNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, personNameLabel);
    });

    saveButton.addEventListener("click", function () {
        var numOfMoviesRow = {
            _personsId: createPersonForm.personsId.value,
            _personsName: createPersonForm.personsName.value,
        };

        var validationResultID = Person.checkPersonsId(personIdLabel.value, Person);
        personIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, personIdLabel);
        var validationResultTitle = Person.checkPersonsName(personNameLabel.value);
        personNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, personNameLabel);
        if (createPersonForm.checkValidity()) {
            Person.create(numOfMoviesRow);
            Person.savePeople();
            createPersonForm.reset();
        }
    });
};

//-- Update ------------------------------------------------------------------------------------------------------------

movieWorld.v.people.updatePerson = function () {
    document.getElementById("saveButton").style.display = "none";
    Person.listAllPersons();
    var updateButton = document.getElementById("updateButton");
    var personToBeUpdated = document.getElementById("selectPersonToBeUpdated");
    var allPeople = Person.instances;
    var updatePersonForm = document.forms['updatePerson'];
    var nameLabel = document.getElementById("names_act2");
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allPeople) {
        var newOption = document.createElement("option");
        newOption.text = allPeople[i]._personsName;
        newOption.value = allPeople[i]._personsId;
        personToBeUpdated.add(newOption);
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }

    personToBeUpdated.addEventListener("change", function () {
        nameLabel.value = allPeople[personToBeUpdated.value]._personsName;
    });

    nameLabel.addEventListener("input", function () {
        var validationResultTitle = Person.checkPersonsName(nameLabel.value);
        nameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, nameLabel);
    });

    updateButton.addEventListener("click", function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (personToBeUpdated.value === arrayOfIDs[i]) {
                var numOfMoviesRow = {
                    _personsId: personToBeUpdated.value,
                    _personsName: nameLabel.value,
                };
                var validationResultTitle = Person.checkPersonsName(nameLabel.value);
                nameLabel.setCustomValidity(validationResultTitle.message);
                setColorToInput(validationResultTitle, nameLabel);
                if (updatePersonForm.checkValidity()) {
                    Person.update(numOfMoviesRow);
                    Person.savePeople();
                    updatePersonForm.reset();
                }
            }
        }
    });
};

//-- Delete ------------------------------------------------------------------------------------------------------------

movieWorld.v.people.deletePerson = function () {
    Person.listAllPersons();
    document.getElementById("saveButton").style.display = "none";
    var deleteButton = document.getElementById("deleteButton");
    var personToBeDeleted = document.getElementById("selectPersonToBeDeleted");
    var allPeople = Person.instances;
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allPeople) {
        var newOption = document.createElement("option");
        newOption.text = allPeople[i]._personsName;
        newOption.value = allPeople[i]._personsId;
        personToBeDeleted.add(newOption)
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }
    deleteButton.onclick = function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (personToBeDeleted.value === arrayOfIDs[i]) {
                Person.delete(arrayOfIDs[i])
            }
        }
        Person.savePeople();
    }
};

//-- List ------------------------------------------------------------------------------------------------------------

movieWorld.v.people.listingAllPersons = function () {
    document.getElementById("saveButton").style.display = "none";
    Person.listAllPersons();
    var allPeople = Person.instances;
    var tableOfPeople = document.getElementById('TableOfAllPeople');
    var localStorageOfActors = JSON.parse(localStorage.getItem("actors"));
    for (let i in allPeople) {
        var newRow = document.createElement("tr");
        newRow.id = "tr_newRow";
        var colOfIDs = document.createElement("td");
        colOfIDs.id = "td_Ids";
        var colOfNames = document.createElement("td");
        colOfNames.id = "td_titles";
        var colOfPersonsTypes = document.createElement("td");
        colOfPersonsTypes.id = "td_plMovies";
        var textOfID = document.createElement("h3");
        var textOfTitles = document.createElement("h3");
        var textOfTypeOfPerson = document.createElement("h3");
        textOfID.textContent = allPeople[i]._personsId;
        colOfIDs.appendChild(textOfID);
        textOfTitles.textContent = allPeople[i]._personsName;
        colOfNames.appendChild(textOfTitles);

        if (allPeople[i] instanceof Actor) {
            textOfTypeOfPerson.textContent = "actor";
            printAgent(localStorageOfActors, allPeople[i], textOfTypeOfPerson);
        } else if (allPeople[i] instanceof Director) {
            textOfTypeOfPerson.textContent = "director";
            printAgent(localStorageOfActors, allPeople[i], textOfTypeOfPerson);
        } else {
            textOfTypeOfPerson.textContent = "person";
            printAgent(localStorageOfActors, allPeople[i], textOfTypeOfPerson);
        }
        colOfPersonsTypes.appendChild(textOfTypeOfPerson);
        newRow.append(colOfIDs, colOfNames, colOfPersonsTypes);
        tableOfPeople.appendChild(newRow)
    }
};

//-- Other ------------------------------------------------------------------------------------------------------------

function goBackToPersonsPage() {
    location.href = "managePerson.html";
}

function printAgent(acto, people, type) {
    for (let actors in acto) {
        if (people._personsId === acto[actors]._agent._personsId) {
            type.textContent += ", agent";
        }
    }
}