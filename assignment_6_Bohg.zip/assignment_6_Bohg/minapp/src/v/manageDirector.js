
//-- Create ------------------------------------------------------------------------------------------------------------

movieWorld.v.directors.createDirector = function () {
    var saveButton = document.getElementById("saveButton");
    Director.listAllDirectors();
    var createDirectorForm = document.forms['createDirector'];
    var directorIdLabel = createDirectorForm.directorsId;
    var directorNameLabel = createDirectorForm.directorsName;
    directorIdLabel.addEventListener("input", function () {
        console.log(directorIdLabel.value)
        var validationResultID = Director.checkPersonsId(directorIdLabel.value, Director);
        console.log(directorIdLabel)
        directorIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, directorIdLabel);

    });

    directorNameLabel.addEventListener("input", function () {
        var validationResultTitle = Director.checkPersonsName(directorNameLabel.value);
        directorNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, directorNameLabel);
    });

    saveButton.addEventListener("click", function () {
        var numOfMoviesRow = {
            _personsId: createDirectorForm.directorsId.value,
            _personsName: createDirectorForm.directorsName.value,
        };

        var validationResultID = Director.checkPersonsId(directorIdLabel.value,Director);
        directorIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, directorIdLabel);
        var validationResultTitle = Director.checkPersonsName(directorNameLabel.value);
        directorNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, directorNameLabel);
        if (createDirectorForm.checkValidity()) {
            Director.create(numOfMoviesRow);
            Director.saveDirectors();
            createDirectorForm.reset();
        }
    });
};

//-- Update ------------------------------------------------------------------------------------------------------------

movieWorld.v.directors.updateDirector = function () {

    document.getElementById("saveButton").style.display = "none";
    Director.listAllDirectors();
    var updateButton = document.getElementById("updateButton");
    var directorToBeUpdated = document.getElementById("selectDirectorToBeUpdated");
    var allDirectors = Director.instances;
    var updateDirectorForm = document.forms['updateDirector'];
    var nameLabel = document.getElementById("names_dir2");
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allDirectors) {
        var newOption = document.createElement("option");
        newOption.text = allDirectors[i]._personsName;
        newOption.value = allDirectors[i]._personsId;
        directorToBeUpdated.add(newOption)
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }
    directorToBeUpdated.addEventListener("change", function () {
        nameLabel.value = allDirectors[directorToBeUpdated.value]._personsName;
    });

    nameLabel.addEventListener("input", function () {
        var validationResultTitle = Director.checkPersonsName(nameLabel.value);
        nameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, nameLabel);
    });

    updateButton.addEventListener("click", function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (directorToBeUpdated.value === arrayOfIDs[i]) {
                var numOfMoviesRow = {
                    _personsId: directorToBeUpdated.value,
                    _personsName: nameLabel.value,
                };
                console.log(numOfMoviesRow)
                var validationResultTitle = Director.checkPersonsName(nameLabel.value);
                nameLabel.setCustomValidity(validationResultTitle.message);
                setColorToInput(validationResultTitle, nameLabel);
                if (updateDirectorForm.checkValidity()) {
                    Director.update(numOfMoviesRow);
                    updateDirectorForm.reset();
                }
            }
        }
    });
};

//-- Delete ------------------------------------------------------------------------------------------------------------

movieWorld.v.directors.deleteDirector = function () {
    Director.listAllDirectors();
    document.getElementById("saveButton").style.display = "none";
    var deleteButton = document.getElementById("deleteButton");
    var directorToBeDeleted = document.getElementById("selectDirectorToBeDeleted");
    var allDirectors = Director.instances;
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allDirectors) {
        var newOption = document.createElement("option");
        newOption.text = allDirectors[i]._personsName;
        newOption.value = allDirectors[i]._personsId;
        directorToBeDeleted.add(newOption)
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }

    deleteButton.onclick = function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (directorToBeDeleted.value === arrayOfIDs[i]) {
                Director.delete(arrayOfIDs[i]);
            }
        }
    }
};

//-- List ------------------------------------------------------------------------------------------------------------

movieWorld.v.directors.listingAllDirectors = function () {
    document.getElementById("saveButton").style.display = "none";
    Director.listAllDirectors();
    Movie.listAllMovies();
    console.log(Movie.instances);

    var allDirectors = Director.instances;
    var tableOfDirectors = document.getElementById('TableOfAllDirectors');
    for (let i in allDirectors) {
        var newRow = document.createElement("tr");
        newRow.id = "tr_newRow";
        var colOfIDs = document.createElement("td");
        colOfIDs.id = "td_Ids";
        var colOfNames = document.createElement("td");
        colOfNames.id = "td_titles";
        var colOfDirectedMovies = document.createElement("td");
        colOfDirectedMovies.id = "td_dirMovies";
        var textOfID = document.createElement("h3");
        var textOfTitles = document.createElement("h3");
        var textOdMovieTitles = document.createElement("h3");
        textOfID.textContent = allDirectors[i]._personsId;
        colOfIDs.appendChild(textOfID);
        textOfTitles.textContent = allDirectors[i]._personsName;
        colOfNames.appendChild(textOfTitles);

        for (let m in Movie.instances) {
            if (Movie.instances[m]._director._personsId
                === allDirectors[i]._personsId) {
                textOdMovieTitles.textContent =
                    Movie.instances[m]._director._directedMovies[m];
            }
        }
        colOfDirectedMovies.appendChild(textOdMovieTitles);
        newRow.append(colOfIDs, colOfNames, colOfDirectedMovies);
        tableOfDirectors.appendChild(newRow)
    }
};

//-- Back ------------------------------------------------------------------------------------------------------------

function goBackToDirectorsPage() {
    location.href = "manageDirectors.html";
}
