
//-- Class actor ----------------------------------------------------------------------------------------------------

class Actor extends Person {
    constructor(row) {
        super(row);
        this._playedMovies = {};
        this._agent = {};
        if (row._agent) {
            this.agent = row._agent;
        }
    }

    get playedMovies() {
        return this._playedMovies;
    }

    get agent() {
        return this._agent;
    }

    set agent(actor) {
        const validationResult = Actor.checkAgent(actor, this);
        if (validationResult instanceof NoConstraintViolation) {
            this._agent = actor;
        } else {
            throw validationResult;
        }
    }

    static checkAgent(person, actor) {
        if (person === undefined) {
            return new NoConstraintViolation();
        }
        if (actor !== undefined) {
            if (actor._playedMovies === undefined) {
                return new ConstraintViolation("Only actors can have agents!");
            } else {
                if (person === undefined || person === {}) {
                    return new MandatoryValueConstraintViolation("You must provide an existing person!")
                } else {
                    return new NoConstraintViolation();
                }
            }
        } else {
            return new MandatoryValueConstraintViolation("You must provide an existing actor!");
        }
    }
}

Actor.instances = {};

//-- Other functions----------------------------------------------------------------------------------------------------

Actor.giveActorKeyRow = function (acto) {
    return new Actor(acto);
};

Actor.create = function (acto) {
    Actor.instances[acto._personsId] = new Actor(acto);
};

Actor.update = function (acto) {
    var storageOfActors = JSON.parse(localStorage.getItem("actors"));
    var actor = Actor.instances[acto._personsId];
    if (actor === undefined) {
        actor = new Actor(acto);
        Actor.instances[acto._personsId] = actor;
    }
    for (let act in storageOfActors) {
        if (storageOfActors[act]._personsId !== actor._personsId) {
            Actor.instances[act] = storageOfActors[act];
        }
    }
    actor._personsName = acto._personsName;
    if (acto._agent) {
        actor._agent = acto._agent;
    }
    Actor.saveActors();
};

Actor.delete = function (aId) {
    console.log(Actor.instances);
    var storageOfActors = JSON.parse(localStorage.getItem("actors"));
    if (typeof Actor.instances[aId] !== "undefined") {
        for (let act in storageOfActors) {
            if (Actor.instances[aId]._personsId === storageOfActors[act]._agent._personsId) {
                Actor.update({
                    _personsId: storageOfActors[act]._personsId,
                    _personsName: storageOfActors[act]._personsName,
                    _agent: {}
                });
            }
        }
        delete Actor.instances[aId];
    } else {
        alert("This actor doesn't exist!");
    }
};

Actor.listAllActors = function () {
    var actorsKey = [];
    var actor = "";
    var allActors = [];
    Actor.instances = {};
    if (typeof localStorage.getItem("actors") !== "undefined") {
        actor = localStorage.getItem("actors");
        allActors = JSON.parse(actor);
        actorsKey = Object.keys(allActors);
        for (let i = 0; i < actorsKey.length; i++) {
            Actor.instances[actorsKey[i]] = Actor.giveActorKeyRow(
                allActors[actorsKey[i]]);
        }
    } else {
        alert("Something went wrong - guess it is your LocalStorage!")
    }
};


Actor.saveActors = function () {
    var actor = "";
    var numOfActors = Object.keys(Actor.instances).length;
    if (numOfActors > 0) {
        actor = JSON.stringify(Actor.instances);
        localStorage.setItem("actors", actor);
        alert("Action successful!")
    } else {
        localStorage.setItem("actors", JSON.stringify(Actor.instances));
    }
};

Actor.saveActorsLoad = function () {
    var actor = "";
    var numOfActors = Object.keys(Actor.instances).length;
    if (numOfActors > 0) {
        actor = JSON.stringify(Actor.instances);
        localStorage.setItem("actors", actor);
    } else {
        localStorage.setItem("actors", JSON.stringify(Actor.instances));
    }
};

Actor.clearTheLocalStorage = function () {
    if (confirm("Are you sure you want to delete all the existing actors?")) {
        Actor.instances = {};
        localStorage.setItem("actors", "{}");
    }
};
