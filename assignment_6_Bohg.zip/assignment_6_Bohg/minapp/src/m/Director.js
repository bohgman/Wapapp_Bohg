
//-- Class director ----------------------------------------------------------------------------------------------------

class Director extends Person {
    constructor(row) {
        super(row);
        this._directedMovies = {};
    }
    get directedMovies() {
        return this._directedMovies;
    }
}

Director.instances = {};

//-- Other functions ---------------------------------------------------------------------------------------------------

Director.giveDirectorKeyRow = function (dire) {
    return new Director(dire);
};

Director.create = function (dire) {
    Director.instances[dire._personsId] = new Director(dire);
};

Director.update = function (dire) {
    Director.instances[dire._personsId]._personsName = dire._personsName;
    Director.saveDirectors();
};


Director.delete = function (dId) {
    var storageOfActors = JSON.parse(localStorage.getItem("actors"));
    if (typeof Director.instances[dId] !== "undefined") {
        for (let act in storageOfActors) {
            if (Director.instances[dId]._personsId === storageOfActors[act]._agent._personsId) {
                Actor.update({
                    _personsId: storageOfActors[act]._personsId,
                    _personsName: storageOfActors[act]._personsName,
                    _agent: {}
                });
            }
        }
        delete Director.instances[dId];
    } else {
        alert("This director doesn't exist!");
    }
    Director.saveDirectors();
};

Director.listAllDirectors = function () {
    var directorsKey = [];
    var director = "";
    var allDirectors = [];
    Director.instances = {};
    if (typeof localStorage.getItem("directors") !== "undefined") {
        director = localStorage.getItem("directors");
        allDirectors = JSON.parse(director);
        directorsKey = Object.keys(allDirectors);
        for (let i = 0; i < directorsKey.length; i++) {
            Director.instances[directorsKey[i]] = Director.giveDirectorKeyRow(
                allDirectors[directorsKey[i]]);
        }
    } else {
        alert("Something went wrong!")
    }
};


Director.saveDirectors = function () {
    var director = "";
    var numOfDirectors = Object.keys(Director.instances).length;
    if (numOfDirectors > 0) {
        director = JSON.stringify(Director.instances);
        localStorage.setItem("directors", director);
        alert("Action successful!")
    } else {
        localStorage.setItem("directors", JSON.stringify(Director.instances));
    }
};

Director.saveDirectorsLoad = function () {
    var director = "";
    var numOfDirectors = Object.keys(Director.instances).length;
    if (numOfDirectors > 0) {
        director = JSON.stringify(Director.instances);
        localStorage.setItem("directors", director);
    } else {
        localStorage.setItem("directors", JSON.stringify(Director.instances));
    }
};

Director.clearTheLocalStorage = function () {
    if (confirm("Are you sure you want to delete all the existing directors?")) {
        Director.instances = {};
        localStorage.setItem("directors", "{}");
    }

};
