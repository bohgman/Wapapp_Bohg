
//-- Class person  ----------------------------------------------------------------------------------------------------

class Person {
    constructor(row) {
        this._personsId = "", this._personsName = "";
        this.personsId = row._personsId;
        this.personsName = row._personsName;
    }

    get personsId() {
        return this._personsId;
    }

    static checkPersonsId(pId, type) {
        var storageOfActors = JSON.parse(localStorage.getItem("actors"));
        var storageOfDirectors = JSON.parse(localStorage.getItem("directors"));
        var storageOfPerson = JSON.parse(localStorage.getItem("people"));
        console.log(Object.keys(Person.instances).length + "Pe");
        console.log(Object.keys(Actor.instances).length + "a");
        console.log(Object.keys(Director.instances).length + "d");
        console.log(storageOfActors[pId]);
        console.log(storageOfPerson);
        console.log(storageOfDirectors[pId]);
        if (typeof pId === "undefined") {
            return new NoConstraintViolation();
        } else if (!util.isNonEmptyString(pId)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty! Give an ID!");
        } else if (!util.isIntegerOrIntegerString(pId)) {
            return new PatternConstraintViolation(
                "The ID should consists only digits!");
        } else {
            if (!pId) {
                return new MandatoryValueConstraintViolation(
                    "Do not leave this one empty!");
            } else if (type.instances[pId] !== undefined) {
                return new UniquenessConstraintViolation(
                    "Your ID is duplicated!");
            } else {
                console.log(type === Actor);
                console.log(type === Director);
                console.log((type === Actor || type === Director));
                if (Object.keys(type.instances).length > 0 &&
                    (type === Actor || type === Director)) {
                    if (Object.keys(Actor.instances).length === 0) {
                        if (storageOfActors[pId] !== undefined) {
                            return new UniquenessConstraintViolation(
                                "Your ID is duplicated!");
                        } else if (storageOfPerson[pId] !== undefined
                            && storageOfPerson[pId]._directedMovies === undefined) {
                            return new UniquenessConstraintViolation(
                                "Your ID is duplicated!");
                        }
                    } else if (Object.keys(Director.instances).length === 0) {
                        if (storageOfDirectors[pId] !== undefined) {
                            return new UniquenessConstraintViolation(
                                "Your ID is duplicated!");
                        } else if (storageOfPerson[pId] !== undefined
                            && storageOfPerson[pId]._playedMovies === undefined) {
                            return new UniquenessConstraintViolation(
                                "Your ID is duplicated!");
                        }
                    }
                } else {
                    if (type === Actor) {
                        if (storageOfPerson[pId] !== undefined) {
                            return new UniquenessConstraintViolation(
                                "Your ID is duplicated!");
                        }
                    } else if (type === Director) {
                        if (storageOfPerson[pId] !== undefined || storageOfActors[pId] !== undefined) {
                            return new UniquenessConstraintViolation(
                                "Your ID is duplicated!");
                        }
                    }
                }
                return new NoConstraintViolation();
            }
        }
    }


    set personsId(pId) {
        const validationResult = Person.checkPersonsId(pId, this.constructor);
        if (validationResult instanceof NoConstraintViolation) {
            this._personsId = pId;
        } else {
            throw validationResult;
        }
    }

    get personsName() {
        return this._personsName;
    }

    static checkPersonsName(name) {
        if (name === undefined || !util.isNonEmptyString(name)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty! Give a name!");
        } else {
            if (util.isNonEmptyString(name)) {
                return new NoConstraintViolation();
            } else {
                return new MandatoryValueConstraintViolation(
                    "Do not leave this one empty! Give a title!");
            }
        }
    }

    set personsName(name) {
        const validationResult = Person.checkPersonsName(name);
        if (validationResult instanceof NoConstraintViolation) {
            this._personsName = name;
        } else {
            throw validationResult;
        }
    }
}

Person.instances = {};

//-- Other functions ---------------------------------------------------------------------------------------------------

Person.givePersonKeyRow = function (perso) {
    return new Person(perso);
};

Person.create = function (perso) {
    Person.instances[perso._personsId] = new Person(perso);
};

Person.update = function (perso) {
    Person.instances[perso._personsId]._personsName = perso._personsName;
};

Person.delete = function (pId) {
    var storageOfActors = JSON.parse(localStorage.getItem("actors"));
    if (typeof Person.instances[pId] !== "undefined") {
        for (let act in storageOfActors) {
            if (Person.instances[pId]._personsId === storageOfActors[act]._agent._personsId) {
                Actor.update({
                    _personsId: storageOfActors[act]._personsId,
                    _personsName: storageOfActors[act]._personsName,
                    _agent: {}
                });
            }
        }
        delete Person.instances[pId];
    } else {
        alert("This person doesn't exist!");
    }
};

Person.listAllPersons = function () {
    var personsKey = [];
    var person = "";
    var allPeople = [];
    var allActors = [];
    var allDirectors = [];
    Person.instances = {};
    Actor.instances = {};
    Director.instances = {};
    if (typeof localStorage.getItem("people") !== "undefined") {
        person = localStorage.getItem("people");
        allPeople = JSON.parse(person);
        allActors = JSON.parse(localStorage.getItem("actors"));
        allDirectors = JSON.parse(localStorage.getItem("directors"));
        personsKey = Object.keys(allPeople);
        giveRow(personsKey, allPeople);
        console.log(Person.instances);
        personsKey = Object.keys(allActors);
        giveRow(personsKey, allActors);
        console.log(Person.instances);
        personsKey = Object.keys(allDirectors);
        giveRow(personsKey, allDirectors);
        console.log(Person.instances);
    } else {
        alert("Something went wrong - guess it is your LocalStorage!")
    }
};

Person.savePeople = function () {
    var person = "";
    var numOfPeople = Object.keys(Person.instances).length;
    if (numOfPeople > 0) {
        person = JSON.stringify(Person.instances);
        localStorage.setItem("people", person);
        alert("Action successful!")
    } else {
        localStorage.setItem("people", JSON.stringify(Person.instances));
    }
};

Person.savePeopleLoad = function () {
    var person = "";
    var numOfPeople = Object.keys(Person.instances).length;
    if (numOfPeople > 0) {
        person = JSON.stringify(Person.instances);
        localStorage.setItem("people", person);
    } else {
        localStorage.setItem("people", JSON.stringify(Person.instances));
    }
};


Person.clearTheLocalStorage = function () {
    if (confirm("Are you sure you want to delete all the existing people?")) {
        Person.instances = {};
        localStorage.setItem("people", "{}");
    }
};

function giveRow(perso, all) {
    var storageOfPeople = JSON.parse(localStorage.getItem("people"));
    var storageOfActors = JSON.parse(localStorage.getItem("actors"));
    var storageOfDirectors = JSON.parse(localStorage.getItem("directors"));
    for (let i = 0; i < perso.length; i++) {
        //if type of person is actor
        if (all[perso[i]]._playedMovies !== undefined) {
            //if an actor was deleted from persons table
            if (storageOfPeople[perso[i]] && storageOfActors[perso[i]]) {
                Person.instances[perso[i]] = Actor.giveActorKeyRow(
                    all[perso[i]]);
                console.log(Person.instances[perso[i]]);
                //if a new actor was added to the table of actors
            } else if (storageOfActors[perso[i]]) {
                Person.instances[perso[i]] = Actor.giveActorKeyRow(
                    all[perso[i]]);
            }
            //if type of person is director
        } else if (all[perso[i]]._directedMovies !== undefined) {
            //if a director was deleted from persons table
            if (storageOfPeople[perso[i]] && storageOfDirectors[perso[i]]) {
                Person.instances[perso[i]] = Director.giveDirectorKeyRow(
                    all[perso[i]]);
                //if a new director was added to the table of directors
            } else if (storageOfDirectors[perso[i]]) {
                Person.instances[perso[i]] = Director.giveDirectorKeyRow(
                    all[perso[i]]);
            }
            //if type of person is person
        } else {
            Person.instances[perso[i]] = Person.givePersonKeyRow(
                all[perso[i]]);
        }
    }
}