/**Constructor function for the class Movie
 * @param {{movieId: number, title: string, releaseDate: number}}
 * numOfMoviesRow - Object creation slots
 @constructor
 * */


var MovieRatingEL = new Enumeration({
    "G": "general Audiences",
    "PG": "Parental Guidance",
    "PG13": "Not Under 13",
    "R": "Restricted",
    "NC17": "Not Under 17"
});

var GenreEL = new Enumeration([
    "Action", "Animation", "Adventure", "Fantasy", "SciFi", "Drama",
    "Family", "FilmNoir", "Romance", "War", "Crime", "Horror",
    "Musical", "Comedy", "Documentary"]);

var MovieCategoryEL = new Enumeration(["Biography", "TVSeriesEpisode"]);

//-- Class movie -------------------------------------------------------------------------------------------------------

class Movie {
    constructor(numOfMoviesRow) {

        this._movieId = "", this._title = "", this._releaseDate = "",
            this._rating = "", this._genres = [], this._director = {},
            this._actors = [], this._typeOfMovie = "", this._about = "",
            this._nameOfTVSerie = "", this._episodeNo = "";
        if (typeof numOfMoviesRow === "object"
            && Object.keys(numOfMoviesRow).length > 0) {
            this.movieId = numOfMoviesRow._movieId;
            this.title = numOfMoviesRow._title;
            if (numOfMoviesRow._releaseDate) {
                this.releaseDate = numOfMoviesRow._releaseDate;
            }
            if (numOfMoviesRow._rating) {
                this._rating = numOfMoviesRow._rating;
            }
            this.genres = numOfMoviesRow._genres;
            if (numOfMoviesRow._typeOfMovie) {
                this.typeOfMovie = numOfMoviesRow._typeOfMovie;
                this.about = numOfMoviesRow._about;
                this.episodeNo = numOfMoviesRow._episodeNo;
                this.nameOfTVSerie = numOfMoviesRow._nameOfTVSerie;
            }
            for (let dir in JSON.parse(localStorage.getItem("directors"))) {
                if (dir === numOfMoviesRow._director._personsId) {
                    this.director = JSON.parse(localStorage.getItem("directors"))[dir];
                }
            }
            var tmpActors = [];
            for (let act in JSON.parse(localStorage.getItem("actors"))) {
                for (let actsInRow of numOfMoviesRow._actors) {
                    if (act === actsInRow._personsId) {
                        tmpActors.push(this.appendingActors(JSON.parse(localStorage.getItem("actors"))[act]));
                    }
                }
            }
            this.actors = tmpActors;
        }
    }

//-- Id ----------------------------------------------------------------------------------------------------------------

    get movieId() {
        return this._movieId;
    }

    static checkId(mId) {
        if (typeof mId === "undefined") {
            return new NoConstraintViolation();
        } else if (!util.isNonEmptyString(mId)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty!");
        } else if (!util.isIntegerOrIntegerString(mId)) {
            return new PatternConstraintViolation(
                "The ID should consists only digits!");
        } else {

            if (!mId) {
                return new MandatoryValueConstraintViolation(
                    "Do not leave this one empty!");
            } else if (Movie.instances[mId] !== undefined) {
                return new UniquenessConstraintViolation(
                    "Your ID is duplicated!");
            } else if (mId < 0) {
                return new PatternConstraintViolation("Your ID should be positiv!");
            } else {
                return new NoConstraintViolation();
            }
        }
    }

    set movieId(mId) {
        const validationResult = Movie.checkId(mId);
        if (validationResult instanceof NoConstraintViolation) {
            this._movieId = mId;
        } else {
            throw validationResult;
        }
    }

    get title() {
        return this._title;
    }

//-- Title -------------------------------------------------------------------------------------------------------------

    static checkTitle(title) {
        if (title === undefined || !util.isNonEmptyString(title)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty!");
        } else {
            if (util.isNonEmptyString(title) && title.length <= 120) {
                return new NoConstraintViolation();
            } else if (title.length > 120) {
                return new StringLengthConstraintViolation(
                    "The title must be not longer than 120 characters!");
            }
        }
    }

    set title(title) {
        const validationResult = Movie.checkTitle(title);
        if (validationResult instanceof NoConstraintViolation) {
            this._title = title;
        } else {
            throw validationResult;
        }
    }

//-- Release -----------------------------------------------------------------------------------------------------------

    get releaseDate() {
        return this._releaseDate;
    }

    static checkReleaseDate(release) {
        if (!isDateOrDateString(release) || release.length < 10)  {
            return new RangeConstraintViolation("The release must be a date of the type: yyyy-mm-dd!");
        } else if (parseDate(release) <  new Date("1895-12-28") || parseDate(release) > new Date()){
            return new IntervalConstraintViolation("The release must be later than 1895-12-28 and not in the future");
        } else {
            return new NoConstraintViolation();
        }
    };

    set releaseDate(release) {
        const validationResult = Movie.checkReleaseDate(release);
        if (validationResult instanceof NoConstraintViolation) {
            this._releaseDate = release;
        } else {
            throw validationResult;
        }
    }

//-- Rating -----------------------------------------------------------------------------------------------------------

    get rating() {
        return this._rating;
    }


    static checkRating(rating) {
        if (rating === undefined || !util.isNonEmptyString(rating)) {
            return new NoConstraintViolation();
        } else if (parseInt(rating) < 1 || parseInt(rating) > MovieRatingEL.MAX) {
            return new RangeConstraintViolation("Invalid value of choice!");
        } else {
            return new NoConstraintViolation();
        }
    }

    set rating(rating) {
        const validationResult = Movie.checkRating(rating);
        if (validationResult instanceof NoConstraintViolation) {
            this._rating = rating;
        } else {
            throw validationResult;
        }

    }

//-- Genre -----------------------------------------------------------------------------------------------------------

    get genres() {
        return this._genres;
    }

    static checkGenres(genres) {
        if (genres === undefined || genres === null
            || (Array.isArray(genres)) && genres.length === 0) {
            return new MandatoryValueConstraintViolation(
                "Don't let the genres " +
                "section empty!")
        } else {
            for (let i = 0; i < genres.length; i++) {
                var validationResult = Movie.checkOneGenre(genres[i]);
                if (!(validationResult instanceof NoConstraintViolation)) {
                    return validationResult;
                }
            }
            return new NoConstraintViolation();
        }
    }

    static checkOneGenre(genre) {
        if (genre === undefined) {
            return new MandatoryValueConstraintViolation("Genres section " +
                "is empty! Give at least one genre!");
        } else if (!Number.isInteger(genre) || genre < 1 || genre > GenreEL.MAX) {
            return new RangeConstraintViolation("Invalid genre");
        } else {
            return new NoConstraintViolation();
        }
    }

    set genres(genres) {
        const validationResult = Movie.checkGenres(genres);
        if (validationResult instanceof NoConstraintViolation) {
            this._genres = genres;
        } else {
            throw validationResult;
        }
    }

//-- Director ----------------------------------------------------------------------------------------------------------

    get director() {
        return this._director;
    }


    static checkDirector(director) {
        if (director.length === 0) {
            return new MandatoryValueConstraintViolation("" +
                "You have to choose at least one director!");
        } else {
            return new NoConstraintViolation();
        }
    }

    set director(director) {
        const validationResult = Movie.checkDirector(director);
        if (validationResult instanceof NoConstraintViolation){
               if (Director.instances[director._personsId] === undefined) {
                Director.instances[director._personsId] = new Director(director);
            }
            this._director = Director.instances[director._personsId];
            this._director.directedMovies[this._movieId] = this._title;
        } else {
            throw validationResult;
        }
    }

//-- Actor -------------------------------------------------------------------------------------------------------------

    get actors() {
        return this._actors;
    }

    static checkActors(actor) {
        if (actor.length === 0) {
            return new MandatoryValueConstraintViolation("" +
                "You have to choose at least one actor!");
        } else {
            return new NoConstraintViolation();
        }
    }

    appendingActors(actor) {
        if (Actor.instances[actor._personsId] === undefined) {
            Actor.instances[actor._personsId] = new Actor(actor);
        }
        actor = Actor.instances[actor._personsId];
        actor.playedMovies[this._movieId] = this._title;
        return actor;
    }

    set actors(actors) {
        this._actors = actors;
    }

//-- Type -------------------------------------------------------------------------------------------------------------

    get typeOfMovie() {
        return this._typeOfMovie;
    }

    set typeOfMovie(type) {
        var validationResult = null;
        if (this.typeOfMovie) {
            validationResult = new FrozenValueConstraintViolation("Once a chosen" +
                "type of movie exists it is not possible to change it");
        } else {
            validationResult = Movie.checkTypeOfMovie(type);
        }
        console.log(validationResult);
        if (validationResult instanceof NoConstraintViolation) {
            this._typeOfMovie = type;
        } else {
            throw validationResult;
        }
    }

    static checkTypeOfMovie(type) {
        if (type === undefined || !util.isNonEmptyString(type)) {
            return new NoConstraintViolation();
        } else if (parseInt(type) < 1 || parseInt(type) > MovieCategoryEL.MAX) {
            return new RangeConstraintViolation("Invalid value of choice!");
        } else {
            return new NoConstraintViolation();
        }
    }

//-- About -------------------------------------------------------------------------------------------------------------

    get about() {
        return this._about;
    }

    set about(about) {
        if (parseInt(this.typeOfMovie) === MovieCategoryEL.BIOGRAPHY) {
            const validationResult = Movie.checkAboutSection(about);
            if (validationResult instanceof NoConstraintViolation) {
                this._about = about;
            } else {
                throw validationResult;
            }
        }


    }

    static checkAboutSection(about) {
        if (about === undefined || !util.isNonEmptyString(about)) {
            return new MandatoryValueConstraintViolation("You can't leave this without explaining what it is about!")
        } else {
            return new NoConstraintViolation();
        }
    }

//-- Episode -------------------------------------------------------------------------------------------------------------

    get episodeNo() {
        return this._episodeNo;
    }

    set episodeNo(no) {
        // we can set a number of tv serie episode only if the category of the movie
        //is TvSeriesEpisode
        if (parseInt(this.typeOfMovie) === MovieCategoryEL.TVSERIESEPISODE) {
            const validationResult = Movie.checkNoOfEpisode(no);
            if (validationResult instanceof NoConstraintViolation) {
                this._episodeNo = no;
            } else {
                throw validationResult;
            }
        }
    }

    static checkNoOfEpisode(no) {
        if (no === undefined || !util.isNonEmptyString(no)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty!");
        } else if (!util.isIntegerOrIntegerString(no)) {
            return new PatternConstraintViolation(
                "Numbers consist only digits!");
        } else {
            return new NoConstraintViolation();
        }
    }

//-- Serie -------------------------------------------------------------------------------------------------------------

    get nameOfTVSerie() {
        return this._nameOfTVSerie;
    }

    set nameOfTVSerie(name) {
        // we can set a name of tv serie episode only if the category of the movie
        //is TvSeriesEpisode
        if (parseInt(this.typeOfMovie) === MovieCategoryEL.TVSERIESEPISODE) {
            const validationResult = Movie.checkNameOfTVSerie(name);
            if (validationResult instanceof NoConstraintViolation) {
                this._nameOfTVSerie = name;
            } else {
                throw validationResult;
            }
        }
    }

    static checkNameOfTVSerie(name) {
        if (name === undefined || !util.isNonEmptyString(name)) {
            return new MandatoryValueConstraintViolation("You can't leave this without a name!")
        } else {
            return new NoConstraintViolation();
        }
    }
}

Movie.instances = {};  // initially an empty collection (a map)

//-- Movie functions ---------------------------------------------------------------------------------------------------

Movie.giveMovieKeyRow = function (mId) {
    return new Movie(mId);
};

Movie.create = function (mId) {
    Movie.instances[mId._movieId] = new Movie(mId);
};

Movie.delete = function (mId) {
    if (typeof Movie.instances[mId] !== "undefined") {
        delete Movie.instances[mId];
    } else {
        alert("Movie with this ID does not exist!");
    }
};

Movie.listAllMovies = function () {
    var movieKeys = [];
    var movie = "";
    var allMovies = [];
    Movie.instances = {};
    if (typeof localStorage.getItem("movies") !== "undefined") {
        movie = localStorage.getItem("movies");
        allMovies = JSON.parse(movie);
        movieKeys = Object.keys(allMovies);
        for (let i = 0; i < movieKeys.length; i++) {
            Movie.instances[movieKeys[i]] = Movie.giveMovieKeyRow(
                allMovies[movieKeys[i]]);
        }
    } else {
        alert("Something went wrong!")
    }
};


Movie.saveAllMovies = function () {
    var movie = "";
    var numOfMovies = Object.keys(Movie.instances).length;
    if (numOfMovies > 0 && confirm("Are you sure you want to save this new data?")) {
        movie = JSON.stringify(Movie.instances);
        localStorage.setItem("movies", movie);
        alert("Action successful!")
    } else {
        alert("There are no movies to be saved!")
    }
};

Movie.update = function (movi) {
    var movie = Movie.instances[movi._movieId];
    movie._title = movi._title;
    movie._releaseDate = movi._releaseDate;
    movie._rating = movi._rating;
    movie._genres = movi._genres;
    movie._director = movi._director;
    movie._actors = movi._actors;
    if (movi._typeOfMovie !== undefined) {
        movie._typeOfMovie = movi._typeOfMovie;
        movie._about = movi._about;
        movie._episodeNo = movi._episodeNo;
        movie._nameOfTVSerie = movi._nameOfTVSerie;
    }
};

Movie.loadTestData = function () {
    Movie.instances = {};
    localStorage.setItem("movies", "{}");
    Director.instances = {};
    localStorage.setItem("directors", "{}");
    Actor.instances = {};
    localStorage.setItem("actors", "{}");
    Person.instances = {};
    localStorage.setItem("people", "{}");

    var dir1 = {_personsId: "3", _personsName: "Quentin Tarantino"};
    var dir2 = {_personsId: "2", _personsName: "George Lucas"};
    var dir3 = {_personsId: "1", _personsName: "Stephen Frears"};
    var person1 = {_personsId: "15", _personsName: "Penka"};
    var person2 = {_personsId: "16", _personsName: "Tonka"};
    var act1 = {_personsId: "5", _personsName: "Uma Thurman", _agent: person1};
    var act2 = {_personsId: "6", _personsName: "John Travolta"};
    var act3 = {_personsId: "7", _personsName: "Ewan McGregor", _agent: dir3};
    var act4 = {_personsId: "8", _personsName: "Natalie Portman", _agent: person2};
    var act5 = {_personsId: "9", _personsName: "Keanu Reeves"};


    Director.create(dir1);
    Director.create(dir2);
    Director.create(dir3);
    Director.saveDirectorsLoad();
    Person.create(person1);
    Person.create(person2);
    Person.savePeopleLoad();
    Actor.create(act1);
    Actor.create(act2);
    Actor.create(act3);
    Actor.create(act4);
    Actor.create(act5);
    Actor.saveActorsLoad();

    Movie.create({
        _movieId: "1", _title: "Pulp Fiction",
        _releaseDate: "1994-05-12", _rating: MovieRatingEL.G,
        _genres: [GenreEL.CRIME, GenreEL.DRAMA],
        _director: dir1,
        _actors: [act1, act2]
    })
    ;
    Movie.create({
        _movieId: "2", _title: "Star Wars", _releaseDate: "1977-05-25",
        _rating: MovieRatingEL.PG13, _genres: [GenreEL.ACTION,
            GenreEL.ADVENTURE, GenreEL.FANTASY, GenreEL.SCIFI],
        _director: dir2,
        _actors: [act3, act4],
        _typeOfMovie: MovieCategoryEL.TVSERIESEPISODE,
        _episodeNo: "4",
        _nameOfTVSerie: "Dart Weider dies"
    });
    Movie.create({
        _movieId: "3", _title: "Dangerous Liaisons", _releaseDate: "1988-12-16",
        _rating: MovieRatingEL.G, _genres: [GenreEL.DRAMA, GenreEL.FILMNOIR,
            GenreEL.ROMANCE, GenreEL.WAR],
        _director: dir3,
        _actors: [act5, act1],
        _typeOfMovie: MovieCategoryEL.BIOGRAPHY,
        _about: "The life of Liaisons"
    });
    Movie.saveAllMovies();
};

Movie.clearTheLocalStorage = function () {
    if (confirm("Are you sure you want to delete ALL the existing movies?")) {
        Movie.instances = {};
        localStorage.setItem("movies", "{}");
    }
};

//-- Helpfunctions -----------------------------------------------------------------------------------------------------

function isDateOrDateString(date) {
    return (date instanceof Date) || !isNaN(Date.parse(date));
}

function parseDate(date) {
    return (date instanceof Date)? date: new Date(date);
}

function cloneObject(obj) {
    var clone = Object.create( Object.getPrototypeOf(obj));
    for (var p in obj) {
        if (obj.hasOwnProperty(p)) {
            if (typeof obj[p] === "number" ||
                typeof obj[p] === "string" ||
                typeof obj[p] === "boolean" ||
                typeName(obj[p]) === "Function" ||
                (typeName(obj[p]) === "Date" && obj[p] != null)) {
                clone[p] = obj[p];
            }
            // else clone[p] = cloneObject(obj[p]);
        }
    }
    return clone;
}