'use strict';

var movieWorld = {
    m: {}, v: {movies: {}, directors: {}, actors: {}, people: {}},
    c: {movies: {}, directors: {}, actors: {}, people: {}}
};
movieWorld.c.initialiseLocalStorage = function () {

    if (localStorage.getItem("movies") === null) {
        localStorage.setItem("movies", "{}");
    }
    if (localStorage.getItem("directors") === null) {
        localStorage.setItem("directors", "{}");
    }
    if (localStorage.getItem("actors") === null) {
        localStorage.setItem("actors", "{}");
    }


};



function setColorToInput(validationResult, label) {
console.log(validationResult)
    label.style.outlineStyle = "solid";
    if (validationResult instanceof NoConstraintViolation) {
        label.style.outlineColor = "green";
    } else {
        label.style.outlineColor = "red";
    }
}


function showChosenSection(idOfElem, functionTOBeLoaded) {
    movieWorld.c.initialiseLocalStorage();
    functionTOBeLoaded;

    var chosenSection = document.getElementById(idOfElem);
    console.log(chosenSection)

    var manageMoviesSection = document.getElementById("movieOptions");
    var optionsDiv = document.getElementById("chosenOption");

    manageMoviesSection.style.display = "none";
    optionsDiv.style.display = "block";
    chosenSection.style.display = "block";
}

function clearTheWholeLocalStorage() {
    if (confirm("Are you sure you want to delete ALL the existing content?")) {
        Movie.instances = {};
        localStorage.setItem("movies", "{}");
        Director.instances = {};
        localStorage.setItem("directors", "{}");
        Actor.instances = {};
        localStorage.setItem("actors", "{}");
        Person.instances = {};
        localStorage.setItem("people", "{}");
    }
}
