/**Constructor function for the class Movie
 * @param {{movieId: number, title: string, releaseDate: number}}
 * numOfMoviesRow - Object creation slots
 @constructor
 * */


var MovieRatingEL = new Enumeration({
    "G": "general Audiences",
    "PG": "Parental Guidance",
    "PG13": "Not Under 13",
    "R": "Restricted",
    "NC17": "Not Under 17"
});

var GenreEL = new Enumeration([
    "Action", "Animation", "Adventure", "Fantasy", "SciFi", "Drama",
    "Family", "FilmNoir", "Romance", "War", "Crime", "Horror",
    "Musical", "Comedy", "Documentary"]);

//-- Class movie -------------------------------------------------------------------------------------------------------

class Movie {
    constructor(numOfMoviesRow) {
        this._movieId = "", this._title = "", this._releaseDate = "",
            this._rating = "", this._genres = [], this._director = {}, this._actors = [];

        if (typeof numOfMoviesRow === "object"
            && Object.keys(numOfMoviesRow).length > 0) {
            this.movieId = numOfMoviesRow._movieId;
            this.title = numOfMoviesRow._title;
            if (numOfMoviesRow._releaseDate) {
                this.releaseDate = numOfMoviesRow._releaseDate;
            }
            if (numOfMoviesRow._rating) {
                this._rating = numOfMoviesRow._rating;
            }
            this.genres = numOfMoviesRow._genres;
            // Director.listAllDirectors();
            var allDirectorsInStorage = JSON.parse(localStorage.getItem("directors"));
            for (let dir in allDirectorsInStorage) {
                if (dir === numOfMoviesRow._director._directorsId) {
                    this.director = allDirectorsInStorage[dir];
                }
            }
            //  Actor.listAllActors();
            var allActorsInStorage = JSON.parse(localStorage.getItem("actors"));
            var tmpActors = [];
            for (let act in allActorsInStorage) {
                for (let actsInRow of numOfMoviesRow._actors) {
                    if (act === actsInRow._actorsId) {
                        tmpActors.push(this.appendingActors(allActorsInStorage[act]));
                    }
                }
            }
            this.actors = tmpActors;
        }
    }

//-- Id ----------------------------------------------------------------------------------------------------------------

    get movieId() {
        return this._movieId;
    }

    static checkId(mId) {
        console.log(mId instanceof Number)
        console.log(mId instanceof String)
        if (typeof mId === "undefined") {
            return new NoConstraintViolation();
        } else if (!util.isNonEmptyString(mId)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty!");
        } else if (!util.isIntegerOrIntegerString(mId)) {
            return new PatternConstraintViolation(
                "The ID should consists only digits!");
        } else {
            if (!mId) {
                return new MandatoryValueConstraintViolation(
                    "Do not leave this one empty!");
            } else if (Movie.instances[mId] !== undefined) {
                return new UniquenessConstraintViolation(
                    "Your ID is duplicated!");
            } else if (mId < 0) {
                return new PatternConstraintViolation("Your ID should be positiv!");
            } else {
                return new NoConstraintViolation();
            }
        }
    }

    set movieId(mId) {
        const validationResult = Movie.checkId(mId);
        if (validationResult instanceof NoConstraintViolation) {
            this._movieId = mId;
        } else {
            throw validationResult;
        }
    }

//-- Title -------------------------------------------------------------------------------------------------------------

    get title() {
        return this._title;
    }

    static checkTitle(title) {
        if (title === undefined || !util.isNonEmptyString(title)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty!");
        } else {
            if (util.isNonEmptyString(title) && title.length <= 120) {
                return new NoConstraintViolation();
            } else if (title.length > 120) {
                return new StringLengthConstraintViolation(
                    "The title must be not longer than 120 characters!");
            }
        }
    }


    set title(title) {
        const validationResult = Movie.checkTitle(title);
        if (validationResult instanceof NoConstraintViolation) {
            this._title = title;
        } else {
            throw validationResult;
        }
    }

//-- Release -----------------------------------------------------------------------------------------------------------

    get releaseDate() {
        return this._releaseDate;
    }

    static checkReleaseDate(release) {
        if  (!isDateOrDateString(release) || release.length < 10)  {
            return new RangeConstraintViolation("The release must be a date of the type: yyyy-mm-dd!");
        } else if (parseDate(release) <  new Date("1895-12-28") || parseDate(release) > new Date()){
            return new IntervalConstraintViolation("The release must be later than 1895-12-28 and not in the future");
        } else {
            return new NoConstraintViolation();
        }
    };


    set releaseDate(release) {
        const validationResult = Movie.checkReleaseDate(release);
        if (validationResult instanceof NoConstraintViolation) {
            this._releaseDate = release;
        } else {
            throw validationResult;
        }
    }

//-- Rating -----------------------------------------------------------------------------------------------------------

    get rating() {
        return this._rating;
    }

    static checkRating(rating) {
        if (rating === undefined || !util.isNonEmptyString(rating)) {
            return new NoConstraintViolation();
        } else if (parseInt(rating) < 1 || parseInt(rating) > MovieRatingEL.MAX) {
            return new RangeConstraintViolation("Invalid value of choice!");
        } else {
            return new NoConstraintViolation();
        }
    }


    set rating(rating) {
        const validationResult = Movie.checkRating(rating);
        if (validationResult instanceof NoConstraintViolation) {
            this._rating = rating;
        } else {
            throw validationResult;
        }

    }

//-- Genre -----------------------------------------------------------------------------------------------------------

    get genres() {
        return this._genres;
    }

    static checkGenres(genres) {
        if (genres === undefined || genres === null
            || (Array.isArray(genres)) && genres.length === 0) {
            return new MandatoryValueConstraintViolation(
                "Don't let this section empty!")
        } else {
            for (let i = 0; i < genres.length; i++) {
                var validationResult = Movie.checkOneGenre(genres[i]);
                if (!(validationResult instanceof NoConstraintViolation)) {
                    return validationResult;
                }
            }
            return new NoConstraintViolation();
        }
    }

    static checkOneGenre(genre) {
        if (genre === undefined) {
            return new MandatoryValueConstraintViolation("Give at least one genre!");
        } else if (!Number.isInteger(genre) || genre < 1 || genre > GenreEL.MAX) {
            return new RangeConstraintViolation("Invalid genre");
        } else {
            return new NoConstraintViolation();
        }
    }

    set genres(genres) {
        const validationResult = Movie.checkGenres(genres);
        if (validationResult instanceof NoConstraintViolation) {
            this._genres = genres;
        } else {
            throw validationResult;
        }
    }

//-- Director ----------------------------------------------------------------------------------------------------------

    get director() {
        return this._director;
    }

    static checkDirector(director) {
        if (director.length === 0) {
            return new MandatoryValueConstraintViolation("" +
                "You have to choose at least one director!");
        } else {
            return new NoConstraintViolation();
        }
    }

    set director(director) {
        Movie.checkDirector(director);
        if (Director.instances[director._directorsId] === undefined) {
            Director.instances[director._directorsId] = new Director(director);
        }
        this._director = Director.instances[director._directorsId];
        this._director.directedMovies[this._movieId] = this._title;
    }

//-- Actor -------------------------------------------------------------------------------------------------------------

    static checkActors(actor) {
        if (actor.length === 0) {
            return new MandatoryValueConstraintViolation("" +
                "You have to choose at least one actor!");
        } else {
            return new NoConstraintViolation();
        }
    }

    addActor(actor) {
        const validationResult = Movie.checkActors(actor);
        if (validationResult instanceof NoConstraintViolation) {
            this._actors[actor._actorsId] = Actor.instances[actor._actorsId];
        } else {
            throw validationResult;
        }
    }

    deleteActor(actor) {
        const validationResult = Movie.checkActors(actor._actorsId);
        if (validationResult instanceof NoConstraintViolation) {
            delete this._actors[actor._actorsId];
        } else {
            throw validationResult;
        }
    }

    get actors() {
        return this._actors;
    }

    appendingActors(actor) {
        if (Actor.instances[actor._actorsId] === undefined) {
            Actor.instances[actor._actorsId] = new Actor(actor);
        }
        actor = Actor.instances[actor._actorsId];
        actor.playedMovies[this._movieId] = this._title;
        return actor;
    }

    set actors(actors) {
        this._actors = actors;
    }
}

Movie.instances = {};  // initially an empty collection (a map)

//-- Movie functions ---------------------------------------------------------------------------------------------------

Movie.giveMovieKeyRow = function (movie) {
    return new Movie(movie);
};

Movie.create = function (movie) {
    Movie.instances[movie._movieId] = new Movie(movie);
};

Movie.delete = function (mId) {
    if (typeof Movie.instances[mId] !== "undefined") {
        delete Movie.instances[mId];
    } else {
        alert("Movie with this ID does not exist!");
    }
};

Movie.listAllMovies = function () {
    var movieKeys = [];
    var movie = "";
    var allMovies = [];
    Movie.instances = {};
    if (typeof localStorage.getItem("movies") !== "undefined") {
        movie = localStorage.getItem("movies");
        allMovies = JSON.parse(movie);
        movieKeys = Object.keys(allMovies);
        for (let i = 0; i < movieKeys.length; i++) {
            Movie.instances[movieKeys[i]] = Movie.giveMovieKeyRow(
                allMovies[movieKeys[i]]);
        }
    } else {
        alert("Something went wrong - guess it is your LocalStorage!")
    }
};


Movie.saveAllMovies = function () {
    var movie = "";
    var numOfMovies = Object.keys(Movie.instances).length;
    if (numOfMovies > 0 && confirm("Are you sure you want save the new data?")) {
        movie = JSON.stringify(Movie.instances);
        localStorage.setItem("movies", movie);
        alert("Action successful!")
    } else {
        alert("There are no movies to be saved!")
    }
};

Movie.update = function (movi) {
    var movie = Movie.instances[movi._movieId];
    movie._title = movi._title;
    movie._releaseDate = movi._releaseDate;
    movie._rating = movi._rating;
    movie._genres = movi._genres;
    movie._director = movi._director;
    movie._actors = movi._actors;
};

Movie.loadTestData = function () {
    Movie.instances = {};
    localStorage.setItem("movies", "{}");
    Director.instances = {};
    localStorage.setItem("directors", "{}");
    Actor.instances = {};
    localStorage.setItem("actors", "{}");

    var dir1 = {_directorsId: "3", _directorsName: "Quentin Tarantino"};
    var dir2 = {_directorsId: "2", _directorsName: "George Lucas"};
    var dir3 = {_directorsId: "1", _directorsName: "Stephen Frears"};
    var act1 = {_actorsId: "5", _actorsName: "Uma Thurman"};
    var act2 = {_actorsId: "6", _actorsName: "John Travolta"};
    var act3 = {_actorsId: "7", _actorsName: "Ewan McGregor"};
    var act4 = {_actorsId: "8", _actorsName: "Natalie Portman"};
    var act5 = {_actorsId: "9", _actorsName: "Keanu Reeves"};

    Director.create(dir1);
    Director.create(dir2);
    Director.create(dir3);
    Actor.create(act1);
    Actor.create(act2);
    Actor.create(act3);
    Actor.create(act4);
    Actor.create(act5);
    Director.saveDirectorsLoad();
    Actor.saveActorsLoad();

    Movie.create({
        _movieId: "1", _title: "Pulp Fiction",
        _releaseDate: "1994-05-12", _rating: MovieRatingEL.G,
        _genres: [GenreEL.CRIME, GenreEL.DRAMA],
        _director: dir1,
        _actors: [act1, act2]
    })
    ;
    Movie.create({
        _movieId: "2", _title: "Star Wars", _releaseDate: "1977-05-25",
        _rating: MovieRatingEL.PG13, _genres: [GenreEL.ACTION,
            GenreEL.ADVENTURE, GenreEL.FANTASY, GenreEL.SCIFI],
        _director: dir2,
        _actors: [act3, act4]
    });
    Movie.create({
        _movieId: "3", _title: "Dangerous Liaisons", _releaseDate: "1988-12-16",
        _rating: MovieRatingEL.G, _genres: [GenreEL.DRAMA, GenreEL.FILMNOIR,
            GenreEL.ROMANCE, GenreEL.WAR],
        _director: dir3,
        _actors: [act5, act1]
    });
    Movie.saveAllMovies();
};

Movie.clearTheLocalStorage = function () {
    if (confirm("Are you sure you want to delete all the existing movies?")) {
        Movie.instances = {};
        localStorage.setItem("movies", "{}");
    }
};

//-- Helpfunctions -----------------------------------------------------------------------------------------------------

function isDateOrDateString(date) {
    return (date instanceof Date) || !isNaN(Date.parse(date));
}

function parseDate(date) {
    return (date instanceof Date)? date: new Date(date);
}