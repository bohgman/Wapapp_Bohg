
//-- Class actor ----------------------------------------------------------------------------------------------------
class Actor {
    constructor(row) {
        this._actorsId = "", this._actorsName = "";
        this.actorsId = row._actorsId;
        this.actorsName = row._actorsName;
        this._playedMovies = {};
    }

    get actorsId() {
        return this._actorsId;
    }

    static checkActorsId(aId) {
        if (typeof aId === "undefined") {
            return new NoConstraintViolation();
        } else if (!util.isNonEmptyString(aId)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty!");
        } else if (!util.isIntegerOrIntegerString(aId)) {
            return new PatternConstraintViolation(
                "The ID should consists only digits!");
        } else {
            if (!aId) {
                return new MandatoryValueConstraintViolation(
                    "Do not leave this one empty!");
            } else if (Actor.instances[aId] !== undefined) {
                return new UniquenessConstraintViolation(
                    "Your ID is duplicated!");
            } else if (aId < 0) {
                return new PatternConstraintViolation("Your ID should be positiv!");
            } else {
                return new NoConstraintViolation();
            }
        }
    }

    set actorsId(aId) {
        const validationResult = Actor.checkActorsId(aId);
        if (validationResult instanceof NoConstraintViolation) {
            this._actorsId = aId;
        } else {
            throw validationResult;
        }
    }

    get actorsName() {
        return this._actorsName;
    }

    static checkActorsName(name) {
        if (name === undefined || !util.isNonEmptyString(name)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty!");
        } else {
            if (util.isNonEmptyString(name)) {
                return new NoConstraintViolation();
            } else {
                return new MandatoryValueConstraintViolation(
                    "Do not leave this one empty!");
            }
        }
    }

    set actorsName(name) {
        const validationResult = Actor.checkActorsName(name);
        if (validationResult instanceof NoConstraintViolation) {
            this._actorsName = name;
        } else {
            throw validationResult;
        }
    }

    get playedMovies() {
        return this._playedMovies;
    }
}

Actor.instances = {};

//-- Other functions----------------------------------------------------------------------------------------------------

Actor.giveActorKeyRow = function (acto) {
    var actor = new Actor(acto);
    return actor;
};

Actor.create = function (acto) {
    var actor = new Actor(acto);
    Actor.instances[acto._actorsId] = actor;
};

Actor.update = function (acto) {
    var actor = Actor.instances[acto._actorsId];
    actor._actorsName = acto._actorsName;
};

Actor.delete = function (aId) {
    if (typeof Actor.instances[aId] !== "undefined") {
        delete Actor.instances[aId];
    } else {
        alert("This actor doesn't exist!");
    }
};

Actor.listAllActors = function () {
    var actorsKey = [];
    var actor = "";
    var allActors = [];
    Actor.instances = {};
    if (typeof localStorage.getItem("actors") !== "undefined") {
        actor = localStorage.getItem("actors");
        allActors = JSON.parse(actor);
        actorsKey = Object.keys(allActors);
        for (let i = 0; i < actorsKey.length; i++) {
            Actor.instances[actorsKey[i]] = Actor.giveActorKeyRow(
                allActors[actorsKey[i]]);
        }
    } else {
        alert("Something went wrong - guess it is your LocalStorage!")
    }
};

Actor.saveActors = function () {
    var actor = "";
    var numOfActors = Object.keys(Actor.instances).length;
    // && confirm("Are you sure you want to save this actor?")
    if (numOfActors > 0) {
        actor = JSON.stringify(Actor.instances);
        localStorage.setItem("actors", actor);
        alert("Action successful!")
    } else {
        alert("There are no actor to be saved!")
    }
};

Actor.saveActorsLoad = function () {
    var actor = "";
    var numOfActors = Object.keys(Actor.instances).length;
    // && confirm("Are you sure you want to save this actor?")
    if (numOfActors > 0) {
        actor = JSON.stringify(Actor.instances);
        localStorage.setItem("actors", actor);
    } else {
        alert("There are no actor to be saved!")
    }
};

Actor.clearTheLocalStorage = function () {
    if (confirm("Are you sure you want to delete all the existing actors?")) {
        Actor.instances = {};
        localStorage.setItem("actors", "{}");
    }
};
