
//-- Class director ----------------------------------------------------------------------------------------------------
class Director {
    constructor(row) {

        this._directorsId = "", this._directorsName = "", this._directedMovies = {};
        this.directorsId = row._directorsId;
        this.directorsName = row._directorsName;
    }

    get directorsId() {
        return this._directorsId;
    }

    static checkDirectorsId(dId) {
        if (typeof dId === "undefined") {
            return new NoConstraintViolation();
        } else if (!util.isNonEmptyString(dId)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty!");
        } else if (!util.isIntegerOrIntegerString(dId)) {
            return new PatternConstraintViolation(
                "The ID should consists only digits!");
        } else {
            if (!dId) {
                return new MandatoryValueConstraintViolation(
                    "Do not leave this one empty!");
            } else if (Director.instances[dId] !== undefined) {
                return new UniquenessConstraintViolation(
                    "Your ID is duplicated!");
            } else if (dId < 0) {
                return new PatternConstraintViolation("Your ID should be positiv!");
            } else {
                return new NoConstraintViolation();
            }
        }
    }

    set directorsId(dId) {
        const validationResult = Director.checkDirectorsId(dId);
        if (validationResult instanceof NoConstraintViolation) {
            this._directorsId = dId;
        } else {
            throw validationResult;
        }
    }

    get directorsName() {
        return this._directorsName;
    }

    static checkDirectorsName(name) {
        if (name === undefined || !util.isNonEmptyString(name)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty!");
        } else {
            if (util.isNonEmptyString(name)) {
                return new NoConstraintViolation();
            }
        }
    }

    set directorsName(name) {
        const validationResult = Director.checkDirectorsName(name);
        if (validationResult instanceof NoConstraintViolation) {
            this._directorsName = name;
        } else {
            throw validationResult;
        }
    }
    get directedMovies() {
        return this._directedMovies;
    }
}

Director.instances = {};

//-- Other functions ---------------------------------------------------------------------------------------------------

Director.giveDirectorKeyRow = function (dire) {
    console.log(Director.instances);
    var director = new Director(dire);
    return director;
};

Director.create = function (dire) {
    var director = new Director(dire);
    Director.instances[dire._directorsId] = director;
};

Director.update = function (dire) {
    console.log(dire);
    var director = Director.instances[dire._directorsId];
    director._directorsName = dire._directorsName;
};

Director.delete = function (dId) {
    if (typeof Director.instances[dId] !== "undefined") {
        delete Director.instances[dId];
    } else {
        alert("This director doesn't exist!");
    }
};

Director.listAllDirectors = function () {
    var directorsKey = [];
    var director = "";
    var allDirectors = [];
    Director.instances = {};
    if (typeof localStorage.getItem("directors") !== "undefined") {
        director = localStorage.getItem("directors");
        allDirectors = JSON.parse(director);
        directorsKey = Object.keys(allDirectors);
        console.log(allDirectors)
        for (let i = 0; i < directorsKey.length; i++) {
            Director.instances[directorsKey[i]] = Director.giveDirectorKeyRow(
                allDirectors[directorsKey[i]]);
        }
    } else {
        alert("Something went wrong - guess it is your LocalStorage!")
    }
};


Director.saveDirectors = function () {
    var director = "";
    var numOfDirectors = Object.keys(Director.instances).length;
    if (numOfDirectors > 0) {
        director = JSON.stringify(Director.instances);
        localStorage.setItem("directors", director);
          alert("Action successfuld!")
    } else {
        alert("There are no director to be saved!")
    }
};

Director.saveDirectorsLoad = function () {
    var director = "";
    var numOfDirectors = Object.keys(Director.instances).length;
    if (numOfDirectors > 0) {
        director = JSON.stringify(Director.instances);
        localStorage.setItem("directors", director);
    } else {
        alert("There are no director to be saved!")
    }
};

Director.clearTheLocalStorage = function () {
    if (confirm("Are you sure you want to delete all the existing directors?")) {
        Director.instances = {};
        localStorage.setItem("directors", "{}");
    }
};
