//not used in this assignment

class Person {
    constructor(row) {

        this._personsId = "", this._personsName = "";
        this.personsId = row._personsId;
        this.personsName = row._personsName;
    }

    get personsId() {
        return this._personsId;
    }


    static checkPersonsId(id) {
        if (typeof id === "undefined") {
            return new NoConstraintViolation();
        } else if (!util.isNonEmptyString(id)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty! Give an ID!");
        } else if (!util.isIntegerOrIntegerString(id)) {
            return new PatternConstraintViolation(
                "The ID should consists only digits!");
        } else {

            if (!id) {
                return new MandatoryValueConstraintViolation(
                    "Do not leave this one empty! Give an ID!");
            } else if (Person.instances[id] !== undefined) {
                return new UniquenessConstraintViolation(
                    "Your ID is duplicated!");
            } else {
                return new NoConstraintViolation();
            }
        }

    }

    set personsId(id) {
        const validationResult = Person.checkPersonsId(id);
        if (validationResult instanceof NoConstraintViolation) {
            this._personsId = id;
        } else {
            throw validationResult;
        }

    }

    get personsName() {
        return this._personsName;
    }

    static checkPersonsName(name) {
        if (name === undefined || !util.isNonEmptyString(name)) {
            return new MandatoryValueConstraintViolation(
                "Do not leave this one empty! Give a name!");

        } else {
            if (util.isNonEmptyString(name)) {
                return new NoConstraintViolation();
            } else {
                return new MandatoryValueConstraintViolation(
                    "Do not leave this one empty! Give a title!");
            }
        }
    }

    set personsName(name) {


        const validationResult = Person.checkPersonsName(name);
        console.log(validationResult)
        console.log(validationResult)
        if (validationResult instanceof NoConstraintViolation) {
            this._personsName = name;
        } else {
            throw validationResult;
        }

    }
}

Person.instances = {};