
//-- Create ------------------------------------------------------------------------------------------------------------

movieWorld.v.actors.createActor = function () {
    var saveButton = document.getElementById("saveButton");
    Actor.listAllActors();
    var createActorForm = document.forms['createActor'];
    var actorIdLabel = createActorForm.actorsId;
    var actorNameLabel = createActorForm.actorsName;
    actorIdLabel.addEventListener("input", function () {
        console.log(actorIdLabel.value);
        var validationResultID = Actor.checkActorsId(actorIdLabel.value);
        actorIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, actorIdLabel);
    });

    actorNameLabel.addEventListener("input", function () {
        var validationResultTitle = Actor.checkActorsName(actorNameLabel.value);
        actorNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, actorNameLabel);
    });

    saveButton.addEventListener("click", function () {
        var numOfMoviesRow = {
            _actorsId: createActorForm.actorsId.value,
            _actorsName: createActorForm.actorsName.value,
        };

        var validationResultID = Actor.checkActorsId(actorIdLabel.value);
        actorIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, actorIdLabel);
        var validationResultTitle = Actor.checkActorsName(actorNameLabel.value);
        actorNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, actorNameLabel);
        if (createActorForm.checkValidity()) {
            Actor.create(numOfMoviesRow)
            Actor.saveActors();
            createActorForm.reset();
        }
    });
};

//-- Update ------------------------------------------------------------------------------------------------------------

movieWorld.v.actors.updateActor = function () {
    document.getElementById("saveButton").style.display = "none";
    Actor.listAllActors();
    var updateButton = document.getElementById("updateButton");
    var actorToBeUpdated = document.getElementById("selectActorToBeUpdated");
    var allActors = Actor.instances;
    var updateActorForm = document.forms['updateActor'];
    var nameLabel = document.getElementById("names_act2");
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allActors) {
        var newOption = document.createElement("option");
        newOption.text = allActors[i]._actorsName;
        newOption.value = allActors[i]._actorsId;
        actorToBeUpdated.add(newOption)
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }
    actorToBeUpdated.addEventListener("change", function () {
        nameLabel.value = allActors[actorToBeUpdated.value]._actorsName;
        console.log(actorToBeUpdated.value)
    });

    nameLabel.addEventListener("input", function () {
        var validationResultTitle = Actor.checkActorsName(nameLabel.value);
        nameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, nameLabel);
    });

    updateButton.addEventListener("click", function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (actorToBeUpdated.value === arrayOfIDs[i]) {
                var numOfMoviesRow = {
                    _actorsId: actorToBeUpdated.value,
                    _actorsName: nameLabel.value,
                };
                var validationResultTitle = Actor.checkActorsName(nameLabel.value);
                nameLabel.setCustomValidity(validationResultTitle.message);
                setColorToInput(validationResultTitle, nameLabel);
                if (updateActorForm.checkValidity()) {
                    Actor.update(numOfMoviesRow);
                    Actor.saveActors();
                    updateActorForm.reset();
                }
            }
        }
    });
};

//-- Delete ------------------------------------------------------------------------------------------------------------

movieWorld.v.actors.deleteActor = function () {
    Actor.listAllActors();
    document.getElementById("saveButton").style.display = "none";
    var deleteButton = document.getElementById("deleteButton");
    var actorToBeDeleted = document.getElementById("selectActorToBeDeleted");
    var allActors = Actor.instances;
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allActors) {
        var newOption = document.createElement("option");
        newOption.text = allActors[i]._actorsName;
        newOption.value = allActors[i]._actorsId;
        actorToBeDeleted.add(newOption)
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }
    deleteButton.onclick = function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (actorToBeDeleted.value === arrayOfIDs[i]) {
                Actor.delete(arrayOfIDs[i])
            }
        }
        Actor.saveActors();
    }
};

//-- List ------------------------------------------------------------------------------------------------------------

movieWorld.v.actors.listingAllActors = function () {
    document.getElementById("saveButton").style.display = "none";
    Actor.listAllActors();
    Movie.listAllMovies();

    var allActors = Actor.instances;
    var tableOfActors = document.getElementById('TableOfAllActors');
    for (let i in allActors) {
        var counterOfActors = 1;
        var newRow = document.createElement("tr");
        newRow.id = "tr_newRow";
        var colOfIDs = document.createElement("td");
        colOfIDs.id = "td_Ids";
        var colOfNames = document.createElement("td");
        colOfNames.id = "td_titles";
        var colOfPlayedMovies = document.createElement("td");
        colOfPlayedMovies.id = "td_plMovies";
        var textOfID = document.createElement("h3");
        var textOfTitles = document.createElement("h3");
        var textOfPlayedMovies = document.createElement("h3");
        textOfID.textContent = allActors[i]._actorsId;
        colOfIDs.appendChild(textOfID);
        textOfTitles.textContent = allActors[i]._actorsName;
        colOfNames.appendChild(textOfTitles);

        console.log(allActors[i]._playedMovies)
        for (let pM in allActors[i]._playedMovies) {
            console.log(Object.keys(allActors[i]._playedMovies).length)
            textOfPlayedMovies.textContent
                += allActors[i]._playedMovies[pM];
            if (counterOfActors < Object.keys(allActors[i]._playedMovies).length) {
                textOfPlayedMovies.textContent += ", "
            }
            counterOfActors++;
        }
        colOfPlayedMovies.appendChild(textOfPlayedMovies);
        newRow.append(colOfIDs, colOfNames, colOfPlayedMovies);
        tableOfActors.appendChild(newRow)
    }
};

//-- Back --------------------------------------------------------------------------------------------------------------

function goBackToActorsPage() {
    location.href = "manageActors.html";
}
