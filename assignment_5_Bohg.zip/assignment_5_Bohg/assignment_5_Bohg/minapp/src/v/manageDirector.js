movieWorld.v.directors.createDirector = function () {
    var saveButton = document.getElementById("saveButton");
    Director.listAllDirectors();
    var createDirectorForm = document.forms['createDirector'];
    var directorIdLabel = createDirectorForm.directorsId;
    var directorNameLabel = createDirectorForm.directorsName;
    directorIdLabel.addEventListener("input", function () {
        console.log(directorIdLabel.value)
        var validationResultID = Director.checkDirectorsId(directorIdLabel.value);
        console.log(directorIdLabel)
        directorIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, directorIdLabel);
    });

    directorNameLabel.addEventListener("input", function () {
        var validationResultTitle = Director.checkDirectorsName(directorNameLabel.value);
        directorNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, directorNameLabel);
    });

    saveButton.addEventListener("click", function () {
        var numOfMoviesRow = {
            _directorsId: createDirectorForm.directorsId.value,
            _directorsName: createDirectorForm.directorsName.value,
        };

        var validationResultID = Director.checkDirectorsId(directorIdLabel.value);
        directorIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, directorIdLabel);
        var validationResultTitle = Director.checkDirectorsName(directorNameLabel.value);
        directorNameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, directorNameLabel);
        if (createDirectorForm.checkValidity()) {
            Director.create(numOfMoviesRow);
            Director.saveDirectors();
            createDirectorForm.reset();
        }
    });
};


movieWorld.v.directors.updateDirector = function () {
    document.getElementById("saveButton").style.display = "none";
    Director.listAllDirectors();
    var updateButton = document.getElementById("updateButton");
    var directorToBeUpdated = document.getElementById("selectDirectorToBeUpdated");
    var allDirectors = Director.instances;
    var updateDirectorForm = document.forms['updateDirector'];
    var nameLabel = document.getElementById("names_dir2");
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allDirectors) {
        var newOption = document.createElement("option");
        newOption.text = allDirectors[i]._directorsName;
        newOption.value = allDirectors[i]._directorsId;
        directorToBeUpdated.add(newOption)
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }

    directorToBeUpdated.addEventListener("change", function () {
        nameLabel.value = allDirectors[directorToBeUpdated.value]._directorsName;
    });

    nameLabel.addEventListener("input", function () {
        var validationResultTitle = Director.checkDirectorsName(nameLabel.value);
        nameLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, nameLabel);
    });

    updateButton.addEventListener("click", function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (directorToBeUpdated.value === arrayOfIDs[i]) {
                var numOfMoviesRow = {
                    _directorsId: directorToBeUpdated.value,
                    _directorsName: nameLabel.value,
                };
                console.log(numOfMoviesRow)
                var validationResultTitle = Director.checkDirectorsName(nameLabel.value);
                nameLabel.setCustomValidity(validationResultTitle.message);
                setColorToInput(validationResultTitle, nameLabel);
                if (updateDirectorForm.checkValidity()) {
                    Director.update(numOfMoviesRow);
                    Director.saveDirectors();
                    updateDirectorForm.reset();
                }
            }
        }
    });
};

movieWorld.v.directors.deleteDirector = function () {
    Director.listAllDirectors();
    document.getElementById("saveButton").style.display = "none";
    var deleteButton = document.getElementById("deleteButton");
    var directorToBeDeleted = document.getElementById("selectDirectorToBeDeleted");
    var allDirectors = Director.instances;
    var arrayOfNames = [];
    var arrayOfIDs = [];
    for (let i in allDirectors) {
        var newOption = document.createElement("option");
        newOption.text = allDirectors[i]._directorsName;
        newOption.value = allDirectors[i]._directorsId;
        directorToBeDeleted.add(newOption)
        arrayOfNames[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }
    deleteButton.onclick = function () {
        for (let i = 1; i < arrayOfNames.length; i++) {
            if (directorToBeDeleted.value === arrayOfIDs[i]) {
                Director.delete(arrayOfIDs[i])
            }
        }
        Director.saveDirectors();
    }
};

movieWorld.v.directors.listingAllDirectors = function () {
    document.getElementById("saveButton").style.display = "none";
    Director.listAllDirectors();
    Movie.listAllMovies();
    console.log(Movie.instances)
    var allDirectors = Director.instances;
    var tableOfDirectors = document.getElementById('TableOfAllDirectors');
    for (let i in allDirectors) {
        var newRow = document.createElement("tr");
        newRow.id = "tr_newRow";
        var colOfIDs = document.createElement("td");
        colOfIDs.id = "td_Ids";
        var colOfNames = document.createElement("td");
        colOfNames.id = "td_titles";
        var colOfDirectedMovies = document.createElement("td");
        colOfDirectedMovies.id = "td_dirMovies";
        var textOfID = document.createElement("h3");
        var textOfTitles = document.createElement("h3");
        var textOdMovieTitles = document.createElement("h3");
        textOfID.textContent = allDirectors[i]._directorsId;
        colOfIDs.appendChild(textOfID);
        textOfTitles.textContent = allDirectors[i]._directorsName;
        colOfNames.appendChild(textOfTitles);
        for (let m in Movie.instances) {
            if (Movie.instances[m]._director._directorsId
                === allDirectors[i]._directorsId) {
                textOdMovieTitles.textContent =
                    Movie.instances[m]._director._directedMovies[m];
            }
        }
        colOfDirectedMovies.appendChild(textOdMovieTitles);
        newRow.append(colOfIDs, colOfNames, colOfDirectedMovies);
        tableOfDirectors.appendChild(newRow)
    }
};

function goBackToDirectorsPage() {
    location.href = "manageDirectors.html";
}
