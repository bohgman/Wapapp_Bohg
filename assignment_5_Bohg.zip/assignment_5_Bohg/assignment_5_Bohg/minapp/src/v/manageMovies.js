
//-- Create ------------------------------------------------------------------------------------------------------------

movieWorld.v.movies.createMovie = function () {

    var saveButton = document.getElementById("saveButton");
    Movie.listAllMovies();
    Director.listAllDirectors();
    Actor.listAllActors();
    var createMovieForm = document.forms['createMovie'];
    var movieIdLabel = createMovieForm.movieId;
    var titleLabel = createMovieForm.title;
    var releaseDateLabel = createMovieForm.releaseDate;
    var ratingSection = document.getElementById("rating");
    var genresSection = document.getElementById("genres");
    var directorSelector = createMovieForm.selectDirector;
    var actorsSelector = createMovieForm.selectActors;
    console.log(ratingSection)

    util.createChoiceWidget(ratingSection, "rating", [],
        "radio",
        MovieRatingEL.labels);
    util.createChoiceWidget(genresSection, "genres", [],
        "checkbox",
        GenreEL.labels, true);
    util.fillSelectWithOptions(directorSelector, Director.instances, "directorsName");
    util.fillSelectWithOptions(actorsSelector, Actor.instances, "actorsName");

    movieIdLabel.addEventListener("input", function () {
        var validationResultID = Movie.checkId(movieIdLabel.value);
        movieIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, movieIdLabel);

    });

    titleLabel.addEventListener("input", function () {
        var validationResultTitle = Movie.checkTitle(titleLabel.value);
        titleLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, titleLabel);
    });

    releaseDateLabel.addEventListener("input", function () {
        var validationResultDate = Movie.checkReleaseDate(releaseDateLabel.value);
        releaseDateLabel.setCustomValidity(validationResultDate.message);
        setColorToInput(validationResultDate, releaseDateLabel);
    });

    ratingSection.addEventListener("click", function () {
        var validationResultRating = Movie.checkRating(ratingSection.getAttribute("data-value"));
        ratingSection.setCustomValidity(validationResultRating.message);
    });

    genresSection.addEventListener("click", function () {
        var validationResultGenre = Movie.checkGenres(JSON.parse(genresSection.getAttribute("data-value")));
        genresSection.setCustomValidity(validationResultGenre.message);
        setColorToInput(validationResultGenre, genresSection);
    });

    var arrayOfActors = [];
    actorsSelector.addEventListener("change", function () {
        arrayOfActors = [];
        for (let opt of actorsSelector.selectedOptions) {
            arrayOfActors.push(Actor.instances[opt.value]);
        }
        console.log(arrayOfActors)
        arrayOfActors = Array.from(new Set(arrayOfActors));
        console.log(arrayOfActors)
        var validationResult = Movie.checkActors(arrayOfActors);
        actorsSelector.setCustomValidity(validationResult.message);
    });

    saveButton.addEventListener("click", function () {
        var numOfMoviesRow = {
            _movieId: createMovieForm.movieId.value,
            _title: createMovieForm.title.value,
            _releaseDate: createMovieForm.releaseDate.value,
            _rating: ratingSection.getAttribute("data-value"),
            _genres: JSON.parse(genresSection.getAttribute("data-value")),
            _director: Director.instances[directorSelector.value],
            _actors: arrayOfActors
        };

        var validationResultID = Movie.checkId(movieIdLabel.value);
        movieIdLabel.setCustomValidity(validationResultID.message);
        setColorToInput(validationResultID, movieIdLabel);

        var validationResultTitle = Movie.checkTitle(titleLabel.value);
        titleLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, titleLabel);

        var validationResultDate = Movie.checkReleaseDate(releaseDateLabel.value);
        releaseDateLabel.setCustomValidity(validationResultDate.message);
        setColorToInput(validationResultDate, releaseDateLabel);

        var validationResultRating = Movie.checkRating(ratingSection.getAttribute("data-value"));
        ratingSection.setCustomValidity(validationResultRating.message);

        var validationResultGenre = Movie.checkGenres(JSON.parse(genresSection.getAttribute("data-value")));

        createMovieForm.genres[1].setCustomValidity(validationResultGenre.message);
        setColorToInput(validationResultGenre, genresSection);

        var validationResult = Movie.checkActors(arrayOfActors);
        actorsSelector.setCustomValidity(validationResult.message);
        setColorToInput(validationResult, actorsSelector);

        if (createMovieForm.checkValidity()) {
            Movie.create(numOfMoviesRow);
            Movie.saveAllMovies();
            createMovieForm.reset();
        }
    });
};

//-- Update ------------------------------------------------------------------------------------------------------------

movieWorld.v.movies.updateMovie = function () {

    document.getElementById("saveButton").style.display = "none";
    Movie.listAllMovies();
    Director.listAllDirectors();
    Actor.listAllActors();
    var updateButton = document.getElementById("updateButton");
    var movieToBeUpdated = document.getElementById("selectMovieToBeUpdated");
    var allMovies = Movie.instances;
    var updateMovieForm = document.forms['updateMovie'];
    var titleLabel = document.getElementById("title2");
    var releaseDateLabel = document.getElementById("releaseDate2");
    var ratingSection = document.getElementById("rating2");
    var genresSection = document.getElementById("genres2");
    var directorSelector = updateMovieForm.selectDirector;
    var actorsSelector = updateMovieForm.selectActors;
    var arrayOfTitles = [];
    var arrayOfIDs = [];

    for (let i in allMovies) {
        var newOption = document.createElement("option");
        newOption.text = allMovies[i].title;
        newOption.value = allMovies[i].movieId;
        movieToBeUpdated.add(newOption);
        arrayOfTitles[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }

    movieToBeUpdated.addEventListener("change", function () {
        titleLabel.value = allMovies[movieToBeUpdated.value].title;
        releaseDateLabel.value = allMovies[movieToBeUpdated.value].releaseDate;

        util.createChoiceWidget(ratingSection, "rating2",
            [allMovies[movieToBeUpdated.value].rating],
            "radio", MovieRatingEL.labels);
        util.createChoiceWidget(genresSection, "genres2",
            allMovies[movieToBeUpdated.value].genres, "checkbox", GenreEL.labels);
        util.fillSelectWithOptions(directorSelector, Director.instances, "directorsName");
        util.fillSelectWithOptions(actorsSelector, Actor.instances, "actorsName");
    });

    titleLabel.addEventListener("input", function () {
        var validationResultTitle = Movie.checkTitle(titleLabel.value);
        titleLabel.setCustomValidity(validationResultTitle.message);
        setColorToInput(validationResultTitle, titleLabel);
    });

    releaseDateLabel.addEventListener("input", function () {
        var validationResultDate = Movie.checkReleaseDate(releaseDateLabel.value);
        releaseDateLabel.setCustomValidity(validationResultDate.message);
        setColorToInput(validationResultDate, releaseDateLabel);
    });

    ratingSection.addEventListener("click", function () {
        var validationResultRating = Movie.checkRating(ratingSection.getAttribute("data-value"));
        ratingSection.setCustomValidity(validationResultRating.message);
    });

    genresSection.addEventListener("click", function () {
        var validationResultGenre = Movie.checkGenres(JSON.parse(genresSection.getAttribute("data-value")));
        genresSection.setCustomValidity(validationResultGenre.message);
        setColorToInput(validationResultGenre, genresSection);
    });

    directorSelector.addEventListener("change", function () {
    });
    var arrayOfActors = [];
    actorsSelector.addEventListener("change", function () {
        arrayOfActors = [];
        for (let opt of actorsSelector.selectedOptions) {
            arrayOfActors.push(Actor.instances[opt.value]);
        }
        arrayOfActors = Array.from(new Set(arrayOfActors));
    });

    updateButton.addEventListener("click", function () {

        for (let i = 1; i < arrayOfTitles.length; i++) {
            if (movieToBeUpdated.value === arrayOfIDs[i]) {
                if (arrayOfActors.length === 0) {
                    arrayOfActors = Movie.instances[movieToBeUpdated.value]._actors;
                }
                var numOfMoviesRow = {
                    _movieId: movieToBeUpdated.value,
                    _title: titleLabel.value,
                    _releaseDate: releaseDateLabel.value,
                    _rating: ratingSection.getAttribute("data-value"),
                    _genres: JSON.parse(genresSection.getAttribute("data-value")),
                    _director: Director.instances[directorSelector.value],
                    _actors: arrayOfActors

                };
                var validationResultTitle = Movie.checkTitle(titleLabel.value);
                titleLabel.setCustomValidity(validationResultTitle.message);
                setColorToInput(validationResultTitle, titleLabel);

                var validationResultDate = Movie.checkReleaseDate(releaseDateLabel.value);
                releaseDateLabel.setCustomValidity(validationResultDate.message);
                setColorToInput(validationResultDate, releaseDateLabel);


                var validationResultRating = Movie.checkRating(ratingSection.getAttribute("data-value"));
                ratingSection.setCustomValidity(validationResultRating.message);

                var validationResultGenre = Movie.checkGenres(JSON.parse(genresSection.getAttribute("data-value")));
                genresSection.setCustomValidity(validationResultGenre.message);
                setColorToInput(validationResultGenre, genresSection);

                if (updateMovieForm.checkValidity()) {
                    Movie.update(numOfMoviesRow);
                    Movie.saveAllMovies();
                    updateMovieForm.reset();
                }
            }
        }
    });
};

//-- Delete ------------------------------------------------------------------------------------------------------------

movieWorld.v.movies.deleteMovie = function () {

    Movie.listAllMovies();
    document.getElementById("saveButton").style.display = "none";
    var deleteButton = document.getElementById("deleteButton");
    var movieToBeDeleted = document.getElementById("selectMovieToBeDeleted");
    var allMovies = Movie.instances;
    var arrayOfTitles = [];
    var arrayOfIDs = [];
    for (let i in allMovies) {
        var newOption = document.createElement("option");
        newOption.text = allMovies[i].title;
        newOption.value = allMovies[i].movieId;
        movieToBeDeleted.add(newOption)
        arrayOfTitles[i] = newOption.text;
        arrayOfIDs[i] = newOption.value;
    }

    deleteButton.onclick = function () {
        for (let i = 1; i < arrayOfTitles.length; i++) {
            if (movieToBeDeleted.value === arrayOfIDs[i]) {
                Movie.delete(arrayOfIDs[i])
            }
        }
        Movie.saveAllMovies();
    }
};

//-- List --------------------------------------------------------------------------------------------------------------

movieWorld.v.movies.listingAllMovies = function () {

    document.getElementById("saveButton").style.display = "none";
    Movie.listAllMovies();
    console.log(Movie.instances)
    var allMovies = Movie.instances;
    var tableOfMovies = document.getElementById('TableOfAllMovie');
    console.log(tableOfMovies)
    for (let i in allMovies) {
        var newRow = document.createElement("tr");
        newRow.id = "tr_newRow";
        var colOfIDs = document.createElement("td");
        colOfIDs.id = "td_Ids";
        var colOfTitles = document.createElement("td");
        colOfTitles.id = "td_titles";
        var colOfDates = document.createElement("td");
        colOfDates.id = "td_dates";
        var colOfRatings = document.createElement("td");
        colOfRatings.id = "td_Ratings";
        var colOfGenres = document.createElement("td");
        colOfGenres.id = "td_Genres";
        var colOfDirectors = document.createElement("td");
        colOfDirectors.id = "td_dirs";
        var colOfActors = document.createElement("td");
        colOfActors.id = "td_acts";

        var textOfID = document.createElement("h3");
        var textOfTitles = document.createElement("h3");
        var textOfDates = document.createElement("h3");
        var textOfRatings = document.createElement("h3");
        var textOfGenres = document.createElement("h3");
        var textOfDirectors = document.createElement("h3");
        var textOfActors = document.createElement("h3");

        textOfID.textContent = allMovies[i].movieId;
        colOfIDs.appendChild(textOfID);
        textOfTitles.textContent = allMovies[i].title;
        colOfTitles.appendChild(textOfTitles);
        textOfDates.textContent = allMovies[i].releaseDate;
        colOfDates.appendChild(textOfDates);
        textOfRatings.textContent = MovieRatingEL.labels[allMovies[i].rating - 1];
        colOfRatings.appendChild(textOfRatings);
        textOfGenres.textContent = GenreEL.convertEnumIndexes2Names(allMovies[i].genres);
        colOfGenres.appendChild(textOfGenres);

        textOfDirectors.textContent = allMovies[i]._director._directorsName;
        colOfDirectors.appendChild(textOfDirectors);
        for (let acts of allMovies[i]._actors) {
            textOfActors.textContent += acts._actorsName;
            if (allMovies[i]._actors[allMovies[i]._actors.length - 1] !== acts) {
                textOfActors.textContent += ", ";
            }
        }
        colOfActors.appendChild(textOfActors);
        console.log(tableOfMovies)
        newRow.append(colOfIDs, colOfTitles, colOfDates, colOfRatings,
            colOfGenres, colOfDirectors, colOfActors);
        tableOfMovies.appendChild(newRow)
    }
};

//-- Back --------------------------------------------------------------------------------------------------------------

function goBackToMoviesPage() {
    location.href = "manageMovies.html";
}

